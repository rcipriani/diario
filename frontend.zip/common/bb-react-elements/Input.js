import React from 'react';

const Input = ({params}) => (
    <div>Aqui é uma input</div>
);

export default Input
