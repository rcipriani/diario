import React, {PureComponent} from 'react'

import _ from 'lodash';

import Highcharts from 'highcharts';

class GraficoPizza extends PureComponent {

    constructor(props) {
        super(props);
        this.chart = null;
        this.modules = [];
    }

    shouldComponentUpdate(nextProps, nextState){
        return false;
    }

    onChartBarClick(fatias) {

        // let novaLista = [];
        // let chips = [];
        //
        // fatias.forEach(function (fatia) {
        //     chips.push(fatia.name);
        //     novaLista = novaLista.concat(fatia.contratos);
        // });
        //
        // if (fatias.length == 0) novaLista = this.props.contratos;
        //
        // this.props.onClickTipo(novaLista);
        //
        // this.setState({chipsFiltros: chips, totalContratosFiltrados: novaLista.length});

    }

    componentDidMount() {

        if (this.modules) {
            this.modules.forEach(function (module) {
                module(Highcharts);
            });
        }

        let _self = this;
        const config = {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie',
                options3d: {
                    enabled: true,
                    alpha: 45,
                    beta: 0
                }
            },
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Contratos',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                pie: {
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '{point.name}'
                    }
                },
                series: {
                    states: {
                        select: {
                            color: '#003658'
                        }
                    },
                    cursor: 'pointer',
                    point: {
                        events: {
                            click: function () {
                                this.slice(null);
                                this.select(null, true);
                                _self.onChartBarClick(this.series.chart.getSelectedPoints());
                            }
                        }
                    },
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                        style: {
                            color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                        }
                    }
                }
            },
            credits: {
                enabled: false
            }
        };

        this.options = Highcharts.merge(config, {
            series: [{
                name: 'Tipos',
                colorByPoint: true,
                allowPointSelect: false,
                data: []
            }]

        });

        this.montaGrafico(this.state.contratos);

    }

    componentWillUnmount() {
        if (this.chart) {
            this.destroyChart();
        }
    }

    montaGrafico(contratos) {

        this.initChart();

        let hoje = MomentHelper(new Date());
        let contratosPorTipo = _.groupBy(contratos, function (contrato) {
            return contrato.codigoAgrupador;
        });

        let dados = [];

        dados = _.map(contratosPorTipo, function (contrato) {

            return {
                name: contrato[0].nomeAgrupador,
                y: contrato.length,
                contratos: contrato
            }
        });


        this.chart.series[0].setData(dados);
        this.initChart();

    }

    initChart() {
        //cria o grafico Chart ou StockChart (Tem que importar o Stock?)
        this.chart = new Highcharts[this.props.type || 'Chart'](
            'chart',
            this.options
        );
    }

    destroyChart() {
        this.chart.destroy();
    }

    render() {

        const {} = this.state;

        return (
            <div id="chart"></div>
        );
    }
}

export default GraficoPizza;