var numeral = require('numeral');
var language = require('numeral/languages/pt-br');

numeral.language('pt-br', language);
numeral.language('pt-br');

var NumeralHelper = numeral;

export default NumeralHelper;
