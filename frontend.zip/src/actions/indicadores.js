/**
 * Created by f9329476 on 27/01/2017.
 */
import * as types from 'actions/actionTypes';
import { createAction } from 'actions';
import api  from 'lib/api';

export const buscaIndicadores = (params, dado) => {
    return createAction(types.BUSCA_ETAPAS,
        api.get('/projeto/relatorio/painelEficiencia/busca/analitico/tarefas', {
                params: {...params, situacaoId: situacaoId}
            }
        ), dado);
};
