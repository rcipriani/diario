/**
 * Created by f9329476 on 27/01/2017.
 */
import * as types from 'actions/actionTypes';
import { createAction } from 'actions';
import api  from 'lib/api';

const SITUACAO_ETAPA = {iniciada: 1, cancelada: 2};

export const buscaEtapasIniciadas = (params, dado) => {

    return buscaEtapas(params, dado, SITUACAO_ETAPA.iniciada);

};

export const buscaEtapasCanceladas = (params, dado) => {

    return buscaEtapas(params, dado, SITUACAO_ETAPA.cancelada);

};

export const recolheEtapas = (tarefa) => {

    return dispatch => dispatch(
        { type: types.RECOLHE_ETAPAS, tarefa }
    )
};

export const expandeEtapas = (tarefa) => {

    return dispatch => dispatch(
        { type: types.EXPANDE_ETAPAS, tarefa }
    )
};

const buscaEtapas = (params, dado, situacaoId) => {
    return createAction(types.BUSCA_ETAPAS,
        api.get('/projeto/relatorio/painelEficiencia/busca/analitico/tarefas', {
                params: {...params, situacaoId: situacaoId}
            }
        ), dado);
};

