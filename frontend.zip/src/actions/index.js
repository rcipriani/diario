export const createAction = (type, promise, args) => {

    return dispatch => {
        dispatch({
            type: type + '_PENDING'
        });
        promise.then(response => {
            dispatch({
                type: type + '_SUCCESS',
                payload: response.data,
                ...args,
            });
        }).catch(err => {
            dispatch({
                type: type + '_FAILURE',
                msg: err.msg,
                error: err
            })
        })
    }
}