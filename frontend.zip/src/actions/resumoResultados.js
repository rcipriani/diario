/**
 * Created by f9329476 on 27/01/2017.
 */
import * as types from 'actions/actionTypes';
import { createAction } from 'actions';
import api  from 'lib/api';

export const buscaResumoResultados = (param) => {

    return createAction(types.BUSCA_RESUMO_RESULTADOS, api.get('/processo/indicadorResultadoProcesso/resultado/processo/12meses'));

};
