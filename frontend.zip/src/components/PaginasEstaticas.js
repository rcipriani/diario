import React, {Component} from 'react';

class PaginasEstaticas extends Component {

    static propTypes = {
        blocos: React.PropTypes.array.isRequired
    };

    componentDidMount() {
        $(document).ready(() => {
            this._initAcccordion();
        });
    }

    componentDidUpdate(){
        this._initAcccordion();
    }

    _initAcccordion(){
        $('.collapsible').collapsible({
            accordion: false // A setting that changes the collapsible behavior to expandable instead of the default accordion style
        });
    }

    render() {

        const {blocos} = this.props;

        function montaBlocos(blocos){
            let ret = [];
            blocos.forEach((bloco, i) => {
                ret.push(
                    <div key={i} className="row">
                        <div className="col s12">
                            <ul className="collapsible z-depth-1" data-collapsible="expandable">
                                <li>
                                    <div className="collapsible-header active">
                                    <span className="blue-text"
                                          style={{fontSize: '1.5rem'}}>{bloco.header}</span>
                                    </div>
                                    <div className="collapsible-body white" style={{display: 'block'}}>
                                        <div className="row">
                                            <div className="col s12">
                                                <img className="background background-cover"
                                                     src={bloco.imagem} />
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                );
            });
            return ret;
        }

        return (
            <div>
                {montaBlocos(blocos)}
            </div>
        );
    }
}

export default PaginasEstaticas;
