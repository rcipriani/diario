import React from 'react';

const TabelaResumoResultados = (props) => {

    console.debug('render', props);

    const periodos = [
        {
            texto: 'out/16'
        },
        {
            texto: 'nov/16'
        },
        {
            texto: 'dez/16'
        },
        {
            texto: 'jan/17'
        },
    ]

    const processos = [
        {
            nome: 'Processo 1',
            indicadores: [
                {
                    nome: 'Indicador 1',
                    apuracoes: [
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                    ]
                },
                {
                    nome: 'Indicador 2',
                    apuracoes: [
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                    ]
                },
            ]
        },
        {
            nome: 'Processo 2',
            indicadores: [
                {
                    nome: 'Indicador 3',
                    apuracoes: [
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                    ]
                },
                {
                    nome: 'Indicador 4',
                    apuracoes: [
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                        {
                            meta: 0,
                            real: 0,
                            desvio: 0,
                        },
                    ]
                },
            ]
        },

    ]

    const ColunaApuracoes = ({indicador}) => {

        return periodos.map((periodo, index) => (
            <td colSpan="3" key={index}>

                <td>
                    {indicador.apuracoes[indexPeriodo].meta}
                </td >
                <td>
                    {indicador.apuracoes[indexPeriodo].real}
                </td >
                <td>
                    {indicador.apuracoes[indexPeriodo].desvio}
                </td >
            </td>
        ))

    }

    const LinhaProcesso = (props) => {

        console.debug('render', props);

        const {processo} = props;

        return processo.indicadores.map((indicador, index) => (

            <tr key={index} >

                {
                    index == 0 &&
                    <td rowSpan={processo.indicadores.length} >
                        {processo.nome}
                    </td>
                }

                <td>
                    {indicador.nome}
                </td>

                <ColunaApuracoes indicador={indicador} />

            </tr>

        ));

    }

    return (

        <table>

            <thead>
                <tr>
                    <td rowSpan="2">
                        PROCESSO
                    </td>
                    <td rowSpan="2">
                        INDICADORES
                    </td>
                    {periodos.map((periodo, index) => (
                        <td colSpan="3" key={index}>
                            {periodo.texto}
                        </td >
                    ))}
                </tr>
                <tr>
                    <td>
                        META
                    </td>
                    <td>
                        REAL
                    </td>
                    <td>
                        DESVIO
                    </td>
                </tr>
            </thead>

            <tbody>

                {processos.map((processo, index) => (

                    <LinhaProcesso processo={processo} key={index} />

                ))}

            </tbody>


        </table>

    )
}

export default TabelaResumoResultados;