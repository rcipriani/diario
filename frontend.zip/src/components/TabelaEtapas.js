/**
 * Created by f9329476 on 24/01/2017.
 */

import React from 'react'
import Farol from './Farol'
import css from './TabelaEtapas.css'
import Data from 'components/Data'

const TabelaEtapasIniciadas = (props) => {

    const {etapasIniciadas, onClickExpansor, showTerminoPrevisto} = props;

    return (
        <table>
            <thead>
                <tr>
                    <td>
                        Processo / Ação / Etapa
                    </td>
                    <td>
                        Nome Responsável
                    </td>
                    {showTerminoPrevisto &&
                        <td>
                            Término Previsto
                        </td>
                    }
                    <td style={{width: '30px'}}></td>
                </tr>
            </thead>
            <tbody>
                {etapasIniciadas.map((dado, index) => {
                    return dado.visivel && <tr className={css.link} onClick={e => onClickExpansor(dado)} key={dado.key}>
                        <td>
                            <div style={{ marginLeft: dado.nivel * 30 }}>
                                {dado.tarefa.nome}
                            </div>
                        </td>
                        <td>
                            {dado.gestor.nome}
                        </td>
                        {showTerminoPrevisto &&
                            <td>
                                <Data data={dado.dataPrevistaFim}/>
                            </td>
                        }
                        <td>
                            {dado.pai &&
                            <i className={['fa', css.link, (dado.expandido ? ' fa-angle-down' : ' fa-angle-right')].join(' ')}
                            aria-hidden="true" onClick={e => onClickExpansor(dado)}>&nbsp;</i>
                        }
                        </td>
                    </tr>
                })}
            </tbody>
        </table>
    );

};

TabelaEtapasIniciadas.propTypes = {
    etapasIniciadas: React.PropTypes.array.isRequired,
    onClickExpansor: React.PropTypes.func.isRequired,
    showTerminoPrevisto: React.PropTypes.bool
};

TabelaEtapasIniciadas.defaultProps = {
    etapasIniciadas: [],
    onClickExpansor: {},
    showTerminoPrevisto: true
};

export default TabelaEtapasIniciadas;