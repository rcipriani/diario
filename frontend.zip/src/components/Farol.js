/**
 * Created by F9329476 on 24/01/2017.
 */

import React, {PureComponent} from 'react'
import css from './Farol.css'

class Farol extends PureComponent {

    constructor(props) {
        super(props);
    }


    render() {

        const {cp} = this.props;
        let classe;

        switch(Math.ceil(cp/10)) {

            case 9:
            case 10:
                 classe = css.verde;
                break;
            case 7:
            case 8:
                 classe = css.amarelo;
                break;
            default:
                 classe = css.vermelho;
                break;
        }
        return (
            <span>
                <i className={"fa fa-circle " + classe}  aria-hidden="true"></i>
            </span>
        )
    }
}

export default Farol;