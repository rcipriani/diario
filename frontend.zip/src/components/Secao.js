import React from 'react'

export const Secao = (props) => {

    const {titulo, children} = props;

    return (
        <div className="container" >

            <div className="row">
                <h2 className="col s12 header white-text">{titulo}</h2>
            </div>

            {children}
        </div>
    )
}

export default Secao;