import React from 'react'
import css from './Legenda.css'

const Legenda = (props) => {

    const {qtdAtraso, qtdImpactada} = props;

    return (
        <table>
            <tbody>
            <tr>

                <td className={css.item}>
                Qtde de etapas em atraso
                </td>
                
                <td>
                    {qtdImpactada || 0}
                </td>    

            </tr>    

            <tr>

                <td className={css.item}>
                Qtde de ações impactadas
                </td>
                
                <td>
                    {qtdAtraso || 0}
                </td>    

            </tr>    
            </tbody>
        </table>    

    )
}

export default Legenda;