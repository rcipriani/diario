/**
 * Created by f9329476 on 25/01/2017.
 */

import React from 'react'
import css from './Quadro.css'

const Quadro = (props) => {

    return (
        <div className={'row ' + css.quadro}>
            {props.children}
        </div>
    );

}

export default Quadro;