/**
 * Created by f9329476 on 24/01/2017.
 */

import React, {Component} from 'react'
import css from './TabelaAcoes.css'
import Data                         from 'components/Data';

class TabelaAcoes extends Component {

    constructor(props) {
        super(props);
    }

    render() {

        const {dadosAnalitico, onClickExpansor} = this.props;

        return (
            <table className="bordered striped highlight">
                <thead className={css.subtitulo}>
                <tr>
                    <td>
                       Ação em Atraso
                    </td>
                    <td>
                        Nome Responsável
                    </td>
                    <td>
                        Término Previsto
                    </td>
                </tr>
                </thead>
                <tbody>
                {
                    dadosAnalitico.map(dado => {
                        return dado.visivel && <tr key={dado.key}>
                            <td>
                                <div style={{marginLeft: dado.nivel * 30}}>
                                    {dado.pai && <i className={['fa', css.link, (dado.expandido? 'fa-minus' : 'fa-plus')].join(' ')} aria-hidden="true" onClick={e => onClickExpansor(dado)}>&nbsp;</i>}
                                    {dado.tarefa.nome}
                                </div>
                            </td>
                            <td>
                                {dado.gestor.nome}
                            </td>
                            <td className="center-align">
                                <Data data={dado.dataPrevistaFim}/>
                            </td>
                        </tr>
                    })
                }
                </tbody>
            </table>
        )
    }
}

export default TabelaAcoes;