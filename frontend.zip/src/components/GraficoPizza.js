/**
 * Created by f9329476 on 23/01/2017.
 */

import React, { PureComponent } from 'react'

import _ from 'lodash';
import MomentHelper from 'helpers/moment-helper';
import Highcharts from 'highcharts';


class GraficoPizza extends PureComponent {


    constructor(props) {
        super(props);
        this.chart = null;
        this.modules = [];

        this.id = "graficoPizza" + Math.random();

        this.state = {
            dadosSintetico: this.props.dadosSintetico,
            chipsFiltros: [],
            totalContratosFiltrados: null
        };
    }

    onChartBarClick(fatias) {

        let novaLista = [];
        let chips = [];

        fatias.forEach(function (fatia) {
            chips.push(fatia.name);
            novaLista = novaLista.concat(fatia.dadosSintetico);
        });

        if (fatias.length == 0) novaLista = this.props.dadosSintetico;

        this.props.onClickTipo(novaLista);

        this.setState({ chipsFiltros: chips, totalContratosFiltrados: novaLista.length });

    }

    componentDidMount() {

        if (this.modules) {
            this.modules.forEach(function (module) {
                module(Highcharts);
            });
        }

        let _self = this;
        const config = {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie',
                options3d: {
                    enabled: true,
                    alpha: 45,
                    beta: 0
                },
                style: {
                    fontFamily: '"Roboto", sans-serif'
                }
            },
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Ações',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                pie: {
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true,
                    pointLabels: true
                    // dataLabels: {
                    //     enabled: true,
                    //     format: '{point.name}'
                    // }

                },
                series: {
                    states: {
                        select: {
                            color: '#003658'
                        }
                    },
                    cursor: 'pointer',
                    point: {
                        events: {
                            click: function () {
                                this.slice(null);
                                this.select(null, true);
                                _self.onChartBarClick(this.series.chart.getSelectedPoints());
                            }
                        }
                    },
                    dataLabels: {
                        enabled: true,
                        format: '{point.percentage:.1f} %',
                        style: {
                            color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                        }
                    }
                }
            },
            credits: {
                enabled: false
            }
        };

        this.options = Highcharts.merge(config, {
            series: [{
                name: 'status',
                colorByPoint: true,
                allowPointSelect: false,
                data: []
            }]

        });

        if (this.props.dadosSintetico) this.montaGrafico(this.props.dadosSintetico);

    }


    componentDidUpdate(prevProps, prevState) {
        if (this.props.dadosSintetico && prevProps.dadosSintetico != this.props.dadosSintetico) {
            this.montaGrafico(this.props.dadosSintetico);
        }
    }

    componentWillUnmount() {
        if (this.chart) {
            this.destroyChart();
        }
    }

    montaGrafico(dadosSintetico) {

        // this.initChart();

        let hoje = MomentHelper(new Date());
        // let acoesPorTipo = _.groupBy(acoes, function (acao) {
        //     return acao.codigoAgrupador;
        // });

        let dados = [];

        // dados = dadosSintetico.map(dado => ({
        //
        //         name: dado[0].status,
        //         y: qtd.length,
        //         acoes: acao
        //     }
        // ));

        dados = dadosSintetico.map(dado => ({
            name: dado.descricao,
            y: dado.qtd
        }
        ));


        console.debug('montando grafico' + this.id);

        this.chart = new Highcharts[this.props.type || 'Chart'](
            this.id,
            this.options
        );

        this.chart.series[0].setData(dados);
    }

    destroyChart() {
        this.chart.destroy();
    }

    render() {

        const {dadosSintetico, chipsFiltros} = this.props;

        let montaChips = function (chips) {
            if (chips) {
                let retorno = [];
                chips.forEach((registro, i) => {
                    retorno.push(
                        <div key={i} className="chip">
                            {registro}
                        </div>
                    );
                });
                return retorno;
            } else {
                return "";
            }
        };

        return (
            <div className="center-align">

                <br />

                <div style={{ display: 'block' }}>
                    <div id={this.id}></div>
                </div>

            </div>
        );
    }
}

export default GraficoPizza;