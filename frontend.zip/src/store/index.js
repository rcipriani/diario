import thunkMiddleware from 'redux-thunk';
import createLogger from 'redux-logger';
import {buscaUsuarioLogado} from 'actions/app';

import {
    createStore,
    applyMiddleware,
    compose,
} from 'redux'

import reducers from 'reducers';

const loggerMiddleware = createLogger();

const store = process.env.AMBIENTE == 'desenvolvimento' ?
    createStore(
        reducers,
        compose(
            applyMiddleware(
                thunkMiddleware,
                // loggerMiddleware
            ),
            window.devToolsExtension ? window.devToolsExtension() : f => f),
    )
    :
    createStore(
        reducers,
        applyMiddleware(thunkMiddleware)
    );

store.dispatch(buscaUsuarioLogado());


export default store;
