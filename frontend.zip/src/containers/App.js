import React, {Component} from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

import {SERVER_BASE_URL, STATIC_SERVER_URL} from 'config';
import {buscaUsuarioLogado} from 'actions/app';
import {Loading} from 'bb-react-elements/Loading';

class App extends Component {

    constructor(props){
        super(props);
    }

    render() {

        const {loading, usuario} = this.props;

        return (
            <MuiThemeProvider>
                <div>
                    {loading > 0 && <Loading />}

                    {usuario &&
                        <div className="row">
                            <a data-activates="slide-out" className="button-collapse waves-effect waves-light btn">Menu</a>

                            <div className="main">
                                {this.props.children}
                            </div>



                            <ul id="slide-out" className="side-nav fixed">
                                <li>
                                    <div className="userView">
                                        <img className="background background-cover"
                                             src={`${STATIC_SERVER_URL}/imgs/commons/bg-desfocado-fachada-edificio-bb.jpg`}/>
                                        <a href="#!user">
                                            <img className="circle"
                                                 src={`https://connections.bb.com.br/profiles/photo.do?uid=${usuario.chave}`}/>
                                        </a>
                                        <a href="#!name"><span className="white-text name">{usuario.nome}</span></a>
                                        <a href="#!email"><span className="white-text email">{usuario.chave}</span></a>
                                    </div>
                                </li>
                                <li><h5 style={{paddingLeft: '10px'}}>Gestão da Eficiência</h5></li>
                                <li><a className="subheader">Compras e Contratações</a></li>
                                <li>
                                    <ul className="collapsible collapsible-accordion" data-collapsible="accordion">
                                        <li>
                                            <div className="collapsible-header ">Frente Processos</div>
                                            <div className="collapsible-body">
                                                <ul>
                                                    {/*<li>*/}
                                                        {/*<Link className="waves-effect" to={`/comprasContratacoes/processos/geral`}>*/}
                                                            {/*Geral*/}
                                                        {/*</Link>*/}
                                                    {/*</li>*/}
                                                    <li>
                                                        <Link className="waves-effect" to={`/comprasContratacoes/processos/painel`}>
                                                            Painel
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link className="waves-effect" to={`/comprasContratacoes/processos/etapas/iniciadas`}>
                                                            Etapas Iniciadas
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link className="waves-effect" to={`/comprasContratacoes/processos/etapas/canceladas`}>
                                                            Etapas Canceladas
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link className="waves-effect" to={`/comprasContratacoes/processos/etapas`}>
                                                            Etapas
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link className="waves-effect" to={`/comprasContratacoes/processos/resumo-resultados`}>
                                                            Resumo dos Resultados
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="collapsible-header active ">Frente Despesas</div>
                                            <div className="collapsible-body">
                                                <ul>
                                                    <li>
                                                        <Link className="waves-effect" to={`/comprasContratacoes/despesas/geral`}>
                                                            Geral
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><div className="divider"></div></li>
                                <li>
                                    <Link className="waves-effect" to={`/comprasContratacoes/indicadores`}>
                                        Indicadores
                                    </Link>
                                </li>
                            </ul>
                        </div>
                        }
                    
                </div>
            </MuiThemeProvider>

        )

    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        loading: state.app.loading,
        usuario: state.app.usuario
    }
};

export default connect(mapStateToProps)(App);

