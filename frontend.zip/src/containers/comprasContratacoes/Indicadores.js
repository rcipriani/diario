import React, {Component} from 'react';
import {STATIC_SERVER_URL} from 'config';
import Quadro from 'components/Quadro';
import Secao from 'components/Secao';

class Indicadores extends Component {

    render() {

        const blocos = [
            {header: 'Indicadores', imagem: `${STATIC_SERVER_URL}/imgs/eficiencia/resultados-indicadores.png`}


        ];

        return (

            <Secao titulo="Indicadores">

                <Quadro>
                    Teste
                </Quadro>

            </Secao>
        );
    }
}

export default Indicadores;
