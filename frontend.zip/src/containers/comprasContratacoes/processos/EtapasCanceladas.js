﻿import React, { Component } from 'react';
import { connect } from 'react-redux';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';

import TabelaEtapas from 'components/TabelaEtapas';
import Quadro from 'components/Quadro';
import Secao from 'components/Secao';
import * as etapasIniciadasActions from 'actions/etapasIniciadas';

import { PROJETO_ID, TAREFA_COMPRAS_CONTRATACOES_ID } from 'constants';


class EtapasCanceladas extends Component {

    params = {
        projetoId: PROJETO_ID,
        tarefaId: TAREFA_COMPRAS_CONTRATACOES_ID
    };

    constructor(props) {
        super(props);

    }

    handleClickExpansor(dado) {

        let params = this.lastParams || this.params;

        if (dado.expandido) {
            this.props.dispatch(etapasIniciadasActions.recolheEtapas(dado));
        } else {
            if (dado.carregado) {
                this.props.dispatch(etapasIniciadasActions.expandeEtapas(dado));
            } else {
                params = { ...params, tarefaId: dado.tarefa.id };
                this.props.dispatch(etapasIniciadasActions.buscaEtapasCanceladas(params, { dado: dado }));
            }
        }

        this.lastParams = params;

    }

    render() {

        const {etapasIniciadas} = this.props;

        return (
            <Secao titulo="Etapas Canceladas">

                <Quadro>

                    <TabelaEtapas
                        etapasIniciadas={etapasIniciadas}
                        onClickExpansor={this.handleClickExpansor.bind(this)}
                        showTerminoPrevisto={false}
                    />

                </Quadro>

            </Secao>
        );
    }
}

// {dadosAnaliticoTarefasAtraso.length && <Quadro>

const mapStateToProps = (state, ownProps) => {
    return {
        etapasIniciadas: state.etapasIniciadas,
    }
};

export default connect(
    mapStateToProps
)(EtapasCanceladas);
