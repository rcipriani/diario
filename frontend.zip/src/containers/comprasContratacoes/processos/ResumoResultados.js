﻿/**
 * Created by f9329476 on 23/01/2017.
 */
import React, { Component } from 'react';
import { connect } from 'react-redux';

import Secao from 'components/Secao';
import Quadro from 'components/Quadro';
import TabelaResumoResultados from 'components/TabelaResumoResultados';

import { PROJETO_ID } from 'constants';

//mock
const dados = [

]

//mock
const periodos = [

]

class ResumoResultados extends Component {

    render() {

        return (

            <Secao titulo="Resumo dos Resultados">

                <Quadro>

                    <TabelaResumoResultados />

                </Quadro>

            </Secao>

        )
    }
}


const mapStateToProps = (state, ownProps) => {
    return {
        indicadores: state.resumoResultados
    }    
};

export default connect(
    mapStateToProps
)(ResumoResultados);

