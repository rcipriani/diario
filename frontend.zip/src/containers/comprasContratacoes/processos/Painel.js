﻿/**
 * Created by f9329476 on 23/01/2017.
 */
import React, {Component} from 'react';
import {connect} from 'react-redux';
import {STATIC_SERVER_URL} from 'config';

import GraficoPizza                 from 'components/GraficoPizza';
import Secao                       from 'components/Secao';
import Quadro                       from 'components/Quadro';
import TabelaAcoes                  from 'components/TabelaAcoes';
import TabelaProcessos              from 'components/TabelaProcessos';
import TabelaProjeto                from 'components/TabelaProjeto';
import Legenda                      from 'components/Legenda';
import {buscaEtapasAtrasoAnalitico, buscaDadosSinteticoAcoes, recolheEtapasAtrasoAnalitico, expandeEtapasAtrasoAnalitico, buscaDadosSinteticoAcoesEtapaAtraso} from 'actions/painel';
import css                          from './Painel.css'
import { PROGRAMA_ID, PROJETO_ID } from 'constants';


class Painel extends Component {

    handleClickEtapasAtraso(dado) {
        let params = {projetoId : PROJETO_ID, tarefaId : dado.id};
        this.subTituloGrafico = dado.nome;
        this.props.dispatch(buscaEtapasAtrasoAnalitico(params));
        this.props.dispatch(buscaDadosSinteticoAcoes(params));
        this.props.dispatch(buscaDadosSinteticoAcoesEtapaAtraso(params));
    }

    handleClickExpansorTarefa(dado) {
        
        if (dado.expandido) {
            this.props.dispatch(recolheEtapasAtrasoAnalitico(dado));
        }else{
            if (dado.carregado){
                this.props.dispatch(expandeEtapasAtrasoAnalitico(dado));
            } else {
                let params = {projetoId : PROJETO_ID, tarefaId : dado.tarefa.id};
                this.props.dispatch(buscaEtapasAtrasoAnalitico(params, {dado : dado}));
            }
        }

    }

    render() {

        const {dadosAnalitico, dadosSintetico, dadosAnaliticoTarefasAtraso, dadosSinteticoAcoes, dadosSinteticoAcoesEtapasAtraso, projeto} = this.props;

        console.debug('dados atraso', dadosSinteticoAcoesEtapasAtraso);

        return (

            <Secao titulo="Acompanhamento das Ações">

                <Quadro>
                        <div>
                            <TabelaProjeto projeto={projeto} />
                        </div>
                </Quadro>

                <Quadro>
                        <div className={css.subtitulo + " col s4"}>
                            <div style={{marginTop:50}}>Status Geral das Ações</div>
                        <GraficoPizza dadosSintetico={dadosSintetico} />
                        </div>
                        <div className="col s8">
                            <TabelaProcessos dadosAnalitico={dadosAnalitico} onClickEtapasAtraso={this.handleClickEtapasAtraso.bind(this)} />
                        </div>
                </Quadro>

                {dadosAnaliticoTarefasAtraso.length ? <Quadro>
                    <div className={css.subtitulo + " col s4"}>
                        <div style={{ marginTop: 50 }}>{this.subTituloGrafico}</div>
                        <GraficoPizza dadosSintetico={dadosSinteticoAcoes} />
                        <Legenda qtdAtraso={dadosSinteticoAcoesEtapasAtraso.qtdAcoesAtraso} qtdImpactada={dadosSinteticoAcoesEtapasAtraso.qtdDemaisAtraso}/>
                    </div>
                    <div className="col s8">
                        <TabelaAcoes dadosAnalitico={dadosAnaliticoTarefasAtraso} onClickExpansor={this.handleClickExpansorTarefa.bind(this)} />
                    </div>
                </Quadro>
                : null}

            </Secao>
        );
    }
}

// {dadosAnaliticoTarefasAtraso.length && <Quadro>

const mapStateToProps = (state, ownProps) => {
    return {
        dadosAnalitico              : state.painel.dadosAnaliticoProcessos,
        dadosAnaliticoTarefasAtraso : state.painel.dadosAnaliticoTarefasAtraso,
        projeto                     : state.painel.projeto,
        dadosSintetico              : state.painel.dadosSinteticoProcessos,
        dadosSinteticoAcoes         : state.painel.dadosSinteticoAcoes,
        dadosSinteticoAcoesEtapasAtraso : state.painel.dadosSinteticoAcoesEtapasAtraso
    }
};

export default connect(
    mapStateToProps
)(Painel);
