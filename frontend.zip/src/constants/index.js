/**
 * Created by F9329476 on 26/01/2017.
 */

export const PROGRAMA_ID = 60;
export const PROJETO_ID = 8604;
export const TAREFA_COMPRAS_CONTRATACOES_ID = 10663;