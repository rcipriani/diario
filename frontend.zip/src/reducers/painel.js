import * as types from 'actions/actionTypes';

const initialState = {

    dadosAnaliticoProcessos: [],
    dadosAnaliticoTarefasAtraso: [],
    dadosSinteticoAcoes: [],
    dadosSinteticoProcessos: [],
    dadosSinteticoAcoesEtapasAtraso: {},
    projeto: {},
};

const painel = (state = initialState, action) => {

    let dados;

    switch (action.type) {
        case types.BUSCA_ANALITICO_PROCESSOS_SUCCESS:
            return {...state, dadosAnaliticoProcessos: action.payload};
        case types.BUSCA_ANALITICO_ETAPAS_ATRASO_SUCCESS:

            console.debug('action', action);

            if (action.dado != undefined) {

                dados = state.dadosAnaliticoTarefasAtraso;

                let tarefaAtual = dados.filter(dado => dado.key == action.dado.key)[0];

                let indexAtual = dados.indexOf(tarefaAtual);

                tarefaAtual.expandido = true;
                tarefaAtual.carregado = true;

                let novosDados = converteDadosAtraso(action.payload, dados.length, action.dado);

                dados.splice.apply(dados, [indexAtual + 1, 0].concat(novosDados));

            } else {

                dados = converteDadosAtraso(action.payload);
            }

            return {...state, dadosAnaliticoTarefasAtraso: dados};
        case types.BUSCA_PROJETO_SUCCESS:
            return {...state, projeto:  (action.payload)};
        case types.BUSCA_SINTETICO_ACOES_SUCCESS:
            return {...state, dadosSinteticoAcoes: converterStatus(action.payload)};
        case types.BUSCA_SINTETICO_PROCESSOS_SUCCESS:
            return { ...state, dadosSinteticoProcessos: converterStatus(action.payload) };
        case types.BUSCA_SINTETICO_ACOES_ETAPAS_ATRASO_SUCCESS:
            return { ...state, dadosSinteticoAcoesEtapasAtraso: action.payload };    
        case types.RECOLHE_ANALITICO_ETAPAS_ATRASO:

            dados = expandeRecolhe(state.dadosAnaliticoTarefasAtraso, action.tarefa, false);

            return {...state, dadosAnaliticoTarefasAtraso: dados.concat([0])};
        case types.EXPANDE_ANALITICO_ETAPAS_ATRASO:

            dados = expandeRecolhe(state.dadosAnaliticoTarefasAtraso, action.tarefa, true);

            return {...state, dadosAnaliticoTarefasAtraso: dados.concat([0])};
    }

    return state;

};

const converterStatus     = (dadosSintetico) => {
    return dadosSintetico.map(dado => {
            let descricao;
            switch (dado.status) {
                case 'SEMPRV':
                    descricao = 'Sem Previsão';
                    break;
                case 'IMPVNC':
                    descricao = 'Impactado por Vencimento';
                    break;
                case 'CONPZO':
                    descricao = 'Concluída no Prazo';
                    break;
                case 'CONANT':
                    descricao = 'Concluída antecipadamente';
                    break;
                case 'CONATR':
                    descricao = 'Concluída em Atraso';
                    break;
                default:
                    descricao = 'Em Andamento';
                    break;
            }

            return {
                ...dado,
                descricao,
            }
        }
    )
};

const expandeRecolhe      = (dados, tarefa, expandir) => {

    let filhos = dados.filter(dado => dado.paiId == tarefa.key);

    let tarefaAtual = dados.filter(dado => dado.key == tarefa.key)[0];

    tarefaAtual.expandido = expandir;

    filhos.forEach(filho => {
            filho.visivel = expandir;
            if (filho.pai && !expandir) expandeRecolhe(dados, filho, false);
        }
    );


    return dados;
};

const converteDadosAtraso = (dados, lastKey, tarefa) => {

    return dados.map((dado, index) => {

        return {
            ...dado,
            paiId: tarefa ? tarefa.key : null,
            key: index + (lastKey || 0),
            visivel: true,
            expandido: false,
            carregado: false,
            nivel: undefined == tarefa ? 0 : tarefa.nivel + 1
        }

    });

};

export default painel;

