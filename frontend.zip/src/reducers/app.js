import * as types from 'actions/actionTypes';

const initialState = {

    erro: null,

    loading: 0,

    usuario: null,

};

const app = (state = initialState, action) => {

    if (/SUCCESS$/.test(action.type)) {
        state = {...state, erro: null, loading: state.loading - 1 };
    } else if (/FAILURE$/.test(action.type)) {
        state = {...state, erro: action.msg || action.error, loading: state.loading - 1 };
        if (!action.msg){
            throw action.error;
        } else {
            console.error(action.error ? action.error.stack : action.error);
        }
    } else if (/PENDING$/.test(action.type)) {
        state = {...state, erro: null, loading: state.loading + 1 };
    }

    if (action.type == types.BUSCA_USUARIO_SUCCESS) {
        state = {...state, usuario: action.payload };
    }

    return state;

};

export default app;
