import { combineReducers } from 'redux';
import {routerReducer} from 'react-router-redux';
import {reducer as formReducer} from 'redux-form';
import app from './app';
import painel from './painel';
import etapasIniciadas from './etapasIniciadas';
import resumoResultados from './resumoResultados';

export default combineReducers({
    app,
    painel,
    etapasIniciadas,
    resumoResultados,
    form : formReducer,
    routing : routerReducer,
})

