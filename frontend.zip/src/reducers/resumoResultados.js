import * as types from 'actions/actionTypes';
import _ from 'lodash';

const initialState = {

};

const resumoResultados = (state = initialState, action) => {
    console.debug('action', action);
    switch (action.type) {
        case types.BUSCA_RESUMO_RESULTADOS_SUCCESS:
            let dados = action.payload;
            let indicadores = _.groupBy(dados, 'codigoIndicador');
            console.debug('grupoindicadores', indicadores);
            return state;
    }
    return state;
};

export default resumoResultados;