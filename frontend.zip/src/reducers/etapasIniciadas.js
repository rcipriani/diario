import * as types from 'actions/actionTypes';

const initialState = [];

const etapasIniciadas = (state = initialState, action) => {

    switch (action.type) {
        case types.BUSCA_ETAPAS_SUCCESS:

            let dados;

            if (action.dado != undefined) {

                dados = state;

                let tarefaAtual = dados.filter(dado => dado.key == action.dado.key)[0];

                let indexAtual = dados.indexOf(tarefaAtual);

                tarefaAtual.expandido = true;
                tarefaAtual.carregado = true;

                let novosDados = converteDados(action.payload, dados.length, action.dado);

                dados.splice.apply(dados, [indexAtual + 1, 0].concat(novosDados));

            } else {

                dados = converteDados(action.payload);
            }

            return dados;
        case types.RECOLHE_ETAPAS:

            dados = expandeRecolhe(state, action.tarefa, false);

            return dados.concat([0]);

        case types.EXPANDE_ETAPAS:

            dados = expandeRecolhe(state, action.tarefa, true);

            return dados.concat([0]);

    }

    return state;

};



const converteDados = (dados, lastKey, tarefa) => {

    return dados.map((dado, index) => {

        return {
            ...dado,
            paiId: tarefa ? tarefa.key : null,
            key: index + (lastKey || 0),
            visivel: true,
            expandido: false,
            carregado: false,
            nivel: undefined == tarefa ? 0 : tarefa.nivel + 1
        }

    });

};


const expandeRecolhe      = (dados, tarefa, expandir) => {

    let filhos = dados.filter(dado => dado.paiId == tarefa.key);

    let tarefaAtual = dados.filter(dado => dado.key == tarefa.key)[0];

    tarefaAtual.expandido = expandir;

    filhos.forEach(filho => {
            filho.visivel = expandir;
            if (filho.pai && !expandir) expandeRecolhe(dados, filho, false);
        }
    );


    return dados;
};

export default etapasIniciadas;