import store from '../store';
import { buscaDadosSinteticoProcessos, buscaDadosAnaliticoProcessos, buscaProjeto } from '../actions/painel';
import { buscaEtapasIniciadas, buscaEtapasCanceladas } from '../actions/etapasIniciadas';
import { buscaResumoResultados } from '../actions/resumoResultados';
import { PROGRAMA_ID, TAREFA_COMPRAS_CONTRATACOES_ID, PROJETO_ID } from 'constants';


export const onPainelEnter = (nextState, replace, callback) => {


    let params = {projetoId: PROJETO_ID, tarefaId: TAREFA_COMPRAS_CONTRATACOES_ID};

    store.dispatch(buscaDadosSinteticoProcessos(params));
    store.dispatch(buscaDadosAnaliticoProcessos(params));
    store.dispatch(buscaProjeto(PROJETO_ID));

    callback();

};

const paramsBuscaEtapas = { projetoId: PROJETO_ID, tarefaId: TAREFA_COMPRAS_CONTRATACOES_ID };

export const onEtapasIniciadasEnter = (nextState, replace, callback) => {
    store.dispatch(buscaEtapasIniciadas(paramsBuscaEtapas));
    callback();
};

export const onEtapasCanceladasEnter = (nextState, replace, callback) => {
    store.dispatch(buscaEtapasCanceladas(paramsBuscaEtapas));
    callback();
};

export const onResumoResultadosEnter = (nextState, replace, callback) => {

    store.dispatch(buscaResumoResultados());

    callback();

};
