import React from 'react';
import { render } from 'react-dom';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';

import App from 'containers/App';
import { APP_URL } from 'config';

import Etapas from 'containers/comprasContratacoes/processos/Etapas';
import EtapasIniciadas from 'containers/comprasContratacoes/processos/EtapasIniciadas';
import EtapasCanceladas from 'containers/comprasContratacoes/processos/EtapasCanceladas';
import Geral from 'containers/comprasContratacoes/processos/Geral';
import Painel from 'containers/comprasContratacoes/processos/Painel';
import Resultados from 'containers/comprasContratacoes/processos/Resultados';
import Indicadores from 'containers/comprasContratacoes/Indicadores';
import ResumoResultados from 'containers/comprasContratacoes/processos/ResumoResultados';
import  * as callbacks from 'routes/callbacks';


const RouterApp = () => {
    return (
        <Router history={browserHistory} key={Math.random()} >
            <Route path={`${APP_URL}` + '/'} component={App}>
                <IndexRoute component={Painel} onEnter={callbacks.onPainelEnter} />
                <Route path="/comprasContratacoes/processos/painel" component={Painel} onEnter={callbacks.onPainelEnter} />
                <Route path="/comprasContratacoes/processos/etapas" component={Etapas} />
                <Route path="/comprasContratacoes/processos/resumo-resultados" component={ResumoResultados} onEnter={callbacks.onResumoResultadosEnter} />
                <Route path="/comprasContratacoes/processos/etapas/iniciadas" component={EtapasIniciadas} onEnter={callbacks.onEtapasIniciadasEnter} />
                <Route path="/comprasContratacoes/processos/etapas/canceladas" component={EtapasCanceladas} onEnter={callbacks.onEtapasCanceladasEnter} />
                <Route path="/comprasContratacoes/processos/geral" component={Geral} />
                <Route path="/comprasContratacoes/processos/resultados" component={Resultados} />
                <Route path="/comprasContratacoes/indicadores" component={Indicadores} />
            </Route>
        </Router>
    );
};

export default RouterApp;