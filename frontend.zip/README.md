# Drive

Aplicação para inclusão de arquivos em páginas do Portal USI

**Tecnologias utilizadas:**

* Node
* Express
* ES6 ou 7
* React
* Babel
* Http (axios)
* HMR (Hot Module Reload)
* Redux
* Devtools (Redux & React)
* Webpack

##Como iniciar:

?

**TODOs**

* URGENTE: Criar controle de acesso para quando acessa diretamente
* URGENTE: Validar se usuário digitou o nome do arquivo
* Dar refresh na tela após cadastrado (Talvez ao fechar modal)
* Implementar ordenação
* Implementar exclusão de arquivos
* Implementar ativação e desativação de arquivos
* Implementar alteração de nome



