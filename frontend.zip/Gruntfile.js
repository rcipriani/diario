module.exports = function(grunt) {

    require('time-grunt')(grunt);

    grunt.file.defaultEncoding = 'utf-8';

    grunt.initConfig({

        //segurança, usuário precisa informar usuário e senha para conexão ao servidor
        prompt: {
            target: {
                options: {
                    questions: [{
                        config: 'admin.user',
                        type: 'input',
                        message: 'user'
                    }, {
                        config: 'admin.pwd',
                        type: 'password',
                        message: 'password'
                    }],
                },

            }
        },

        //limpa a pasta de build
        clean: {
            dist: {
                src: 'dist'
            }
        },

        //copia para a pasta de build
        copy: {
            public: {
                expand: true,
                cwd: 'public',
                src: '**',
                dest: 'dist'
            },
            fonts: {
                expand: true,
                cwd: 'public/fonts',
                src: '**',
                dest: 'dist/assets/fonts/'
            }
        },

        //prepara as configurações de concat
        useminPrepare: {
            html: 'dist/**/index.html',
            options: {
                flow: {
                    steps: {
                        js: ['concat'],
                        css: ['concat']
                    }
                }
            }
        },

        //finaliza a execução do concat
        usemin: {
            html: 'dist/**/*.html',
            options: {
                assetsDirs: ['dist', 'dist/assets'],
            }
        },

        //altera os nomes dos arquivos alterados, para otimização do cache
        filerev: {
            dist: {
                src: ['dist/assets/**/*.js', 'dist/assets/**/*.css']
            }
        },

        //minifica o html
        htmlmin: {
            dist: {
                options: {
                    removeComments: true,
                    collapseWhitespace: true,
                    minifyJS: true,
                    minifyCSS: true
                },
                expand: true,
                cwd: 'dist',
                src: ['**/*.html', '!**/node_modules/**', '!platinum/**'],
                dest: 'dist'
            },
        },


        //inclui as porções de html pelo ng-include
        nginclude: {
            dist: {
                files: [{
                    expand: true,
                    cwd: 'dist',
                    src: ['**/*.html', '!platinum/**'],
                    dest: 'dist'
                }]
            },
        },


        //testes frontend
        karma: {
            unit: {
                configFile: 'config/karma.config.js',
                singleRun: true
            }
        },


        //testes backend
        simplemocha: {
            all: {
                src: ['tests/**/*.js'],
            },
        },

        //testes backend
        mochaTest: {
            options: {
                require : 'tests/config',
            },
            all: {
                // src: ['tests/projeto/*.js', 'tests/util/*.js', 'tests/global/*.js', 'tests/portal/*.js'],
                src: ['tests/projeto/*.js'],
            }
        },

        //mecanismo de deploy
        shell: {
            deploy: {
                command: function() {

                    var user = process.env.DEPLOY_USER || grunt.config('admin.user'),
                        pwd = process.env.DEPLOY_PWD || grunt.config('admin.pwd');

                    var isWindows = /^win/.test(process.platform);

                    var cmd = isWindows ? 'deploy.bat' : 'sh deploy.sh',
                        join = isWindows ? '&' : '&&';

                    var ips = ['172.20.0.165', '172.20.0.167'];

                    var cmds = ips.map(function(ip) {
                        return [cmd, user, pwd, ip].join(' ');
                    });

                    return cmds.join(' ' + join + ' ');

                },
                options: {
                    execOptions: {
                        maxBuffer: Infinity
                    }
                }
            },

            homologa: {
                command: function() {

                    var user = process.env.DEPLOY_USER || grunt.config('admin.user'),
                        pwd = process.env.DEPLOY_PWD || grunt.config('admin.pwd');

                    var isWindows = /^win/.test(process.platform);

                    var cmd = isWindows ? 'deploy.bat' : 'sh deploy.sh';

                    return [cmd, user, pwd, '172.17.191.72', 'homologacao'].join(' ');
                },
                options: {
                    execOptions: {
                        maxBuffer: Infinity
                    }
                }
            },

            dev: {
                command: function() {

                    var user = process.env.DEPLOY_USER || grunt.config('admin.user'),
                        pwd = process.env.DEPLOY_PWD || grunt.config('admin.pwd');

                    var isWindows = /^win/.test(process.platform);

                    var cmd = isWindows ? 'deploy.bat' : 'sh deploy.sh';

                    return [cmd, user, pwd, '172.17.85.80'].join(' ');
                },
                options: {
                    execOptions: {
                        maxBuffer: Infinity
                    }
                }
            },

        },

        //minifica js
        uglify: {
            options: {
                mangle: false,
            },
            dist: {
                files: [{
                    expand: true,
                    cwd: 'dist',
                    src: ['**/*.js', '!**/*min.js', '!**/node_modules/**', '!platinum/**'],
                    dest: 'dist',
                }]
            }
        },


        //minifica css
        cssmin: {
            dist: {
                files: [{
                    expand: true,
                    cwd: 'dist',
                    src: ['**/*.css', '!**/*min.css'],
                    dest: 'dist',
                }]
            }
        },


        //para uso em desenvolvimento, recarrega a página em caso de alterações
        concurrent: {
            dev: {
                tasks: ['nodemon', 'watch'],
                options: {
                    logConcurrentOutput: true
                }
            }
        },

        //para uso em desenvolvimento, recarrega a página em caso de alterações
        nodemon: {
            dev: {
                script: 'index.js',
                options: {
                    //nodeArgs: ['--debug'],
                    ignore: ['.tmp/*', 'dist/*', 'public/*', 'log/*', 'uploads/*', '.git/*', '*.sql', 'node_modules/*'],
                    env: {
                        PORT: '3000'
                    },
                    // omit this property if you aren't serving HTML files and
                    // don't want to open a browser tab on start
                    callback: function(nodemon) {

                        nodemon.on('log', function(event) {
                            console.log(event.colour);
                        });

                        // opens browser on initial server start
                        nodemon.on('config:update', function() {
                            // Delay before server listens on port
                            setTimeout(function() {
                                require('open')('http://localhost.bb.com.br:3000');
                            }, 1000);
                        });

                        // refreshes browser when server reboots
                        nodemon.on('restart', function() {
                            // Delay before server listens on port
                            setTimeout(function() {
                                require('fs').writeFileSync('.rebooted', 'rebooted');
                            }, 2000);
                        });
                    }
                }
            }
        },

        //para uso em desenvolvimento, recarrega a página em caso de alterações
        watch: {
            server: {
                files: ['.rebooted', 'public/**/*.*', '!**.ts', '../models/**/*.js'],
                options: {
                    livereload: true
                }
            }
        },

        //remove trechos de código usados somente para desenvolvimento (log, livereload, etc)
        preprocess: {
            options: {
                context: {
                    DEBUG: false
                }
            },
            dist: {
                expand: true,
                src: ['**/index.html', '**/*App.js', '!**/*min.js'],
                cwd: 'dist',
                dest: 'dist',
            }
        }


    });

    //agrupamento e definições das tarefas
    grunt.registerTask('copia', ['clean', 'copy']);
    grunt.registerTask('minifica', ['uglify', 'cssmin', 'useminPrepare', 'concat', 'filerev', 'usemin', 'htmlmin']);
    grunt.registerTask('otimiza', ['preprocess', 'nginclude']);
    grunt.registerTask('test', ['mochaTest']);
    grunt.registerTask('build', ['copia', 'otimiza', 'minifica']);


    grunt.registerTask('deploy', function() {

        var tasks = ['shell:deploy'];

        if (!process.env.DEPLOY_USER) tasks.unshift('prompt');

        grunt.task.run(tasks);

    });

    grunt.registerTask('homologa', function() {

        var tasks = ['shell:homologa'];

        if (!process.env.DEPLOY_USER) tasks.unshift('prompt');

        grunt.task.run(tasks);

    });

    grunt.registerTask('dev', function() {

        var tasks = ['test', 'shell:desenv'];

        if (!process.env.DEPLOY_USER) tasks.unshift('prompt');

        grunt.task.run(tasks);

    });

    grunt.registerTask("tsdev", ["ts:dev"]);

    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-usemin');
    grunt.loadNpmTasks('grunt-contrib-htmlmin');
    grunt.loadNpmTasks('grunt-nginclude');
    grunt.loadNpmTasks('grunt-filerev');
    grunt.loadNpmTasks('grunt-karma');
    grunt.loadNpmTasks('grunt-simple-mocha');
    grunt.loadNpmTasks('grunt-shell');
    grunt.loadNpmTasks('grunt-prompt');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-open');
    grunt.loadNpmTasks('grunt-ts');
    grunt.loadNpmTasks('grunt-nodemon');
    grunt.loadNpmTasks('grunt-preprocess');
    grunt.loadNpmTasks('grunt-concurrent');
    grunt.loadNpmTasks('grunt-processhtml');
    grunt.loadNpmTasks('grunt-mocha-test');

}
