

import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import store from 'store';
import Home from 'containers/Home';
import Root from 'containers/Root';
import Cadastro from 'containers/Cadastro';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
import { useRouterHistory } from 'react-router';
import { syncHistoryWithStore } from 'react-router-redux';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import {APP_URL} from 'config';
import injectTapEventPlugin from 'react-tap-event-plugin'; //remover assim que sair a versão oficial do react http://www.material-ui.com/#/get-started/installation

const history = syncHistoryWithStore(browserHistory, store);

injectTapEventPlugin(); //remover depois que sair versão oficial do react http://www.material-ui.com/#/get-started/installation

render(
    <Provider store={store}>
        <MuiThemeProvider>
            <Router history={history}>
                <Route path={APP_URL ? APP_URL : '/'} component={Root}>
                    <IndexRoute component={Home}/>
                    <Route path="lista/:tipo/:uor" component={Home} />
                    <Route path="cadastro/:numero/:ano" component={Cadastro} />
                </Route>
            </Router>
        </MuiThemeProvider>
    </Provider>,
    document.getElementById('container')
)


