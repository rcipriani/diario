var gulp = require('gulp');
var webpack = require('webpack');
var webpackConfig = require('./webpack.production.config.js');
var GulpSSH = require('gulp-ssh');

// configure defaults
var serverConfig = {
    root_folder: "projeto_rot"
};

try {
    serverConfigLoader = require('./src/config/server-config.json');
    Object.assign(serverConfig, serverConfigLoader);
} catch (e) {
    if (e instanceof Error && e.code === "MODULE_NOT_FOUND")
        console.log("Arquivo de configuração do server não encontrado!");
    else
        throw e;
}

gulp.task('build', function (callback) {

    webpack(webpackConfig, function (err, stats) {
        if (err) throw new Error("webpack", err);
        callback();
    });

});


/**
 *
 * Configurações para upload dos arquivos para o servidor
 *
 * */
var remoteFolder = "/app/" + serverConfig.root_folder + "/frontend/public";
var remoteServerFolder = "/app/" + serverConfig.root_folder + "/server";

var configAppServer1 = {
    host: '172.20.0.165',
    port: 22,
    username: process.env.DEPLOY_USER,
    password: process.env.DEPLOY_PWD
};

var configHomologServer = {
    host: '172.17.191.72',
    port: 22,
    username: process.env.DEPLOY_USER,
    password: process.env.DEPLOY_PWD
};

var configAppServer2 = Object.assign({}, configAppServer1, { host: '172.20.0.167' });

var gulpSSHAppServer1 = new GulpSSH({
    ignoreErrors: false,
    sshConfig: configAppServer1
});

var gulpSSHAppServer2 = new GulpSSH({
    ignoreErrors: false,
    sshConfig: configAppServer2
});

var gulpSSHHomologServer = new GulpSSH({
    ignoreErrors: false,
    sshConfig: configHomologServer
});

gulp.task('deploy', ['build'], function () {

    gulp.src(['./public/**'])
        .pipe(gulpSSHAppServer1.dest(remoteFolder));
    gulp.src(['./public/**'])
        .pipe(gulpSSHAppServer2.dest(remoteFolder));

    return true;
});

gulp.task('deploy:server', function () {

    gulp.src(['../server/**', '!../server/node_modules/**'])
        .pipe(gulpSSHAppServer1.dest(remoteServerFolder));
    gulp.src(['../server/**', '!../server/node_modules/**'])
        .pipe(gulpSSHAppServer2.dest(remoteServerFolder));

    return true;
});

gulp.task('homolog:back', function () {

    gulp.src(['./server/**'])
        .pipe(gulpSSHHomologServer.dest(remoteServerFolder));
    return true;
});


// The default task (called when you run `gulp` from cli)
gulp.task('default', ['deploy']);
