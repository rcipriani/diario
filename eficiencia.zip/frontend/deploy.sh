#!/bin/sh
echo "deploy no servidor $4"
ssh $1@$3 "sh /app/fornecedores/start.sh $4"
