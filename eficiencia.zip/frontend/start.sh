#!/bin/sh

cd /app/eficiencia/server

PROFILE=~/.profile
BRANCH=master

if [ -f "/etc/redhat-release" ]; then
  PROFILE=~/.bash_profile
fi

source $PROFILE

if [ "x$1" != "x" ]; then
    BRANCH=$1
fi

echo "Usando a branch $BRANCH"

git checkout $BRANCH

echo 'Atualizando dados via git'
git pull

echo 'Encerrando aplicação'
pm2 stop eficiencia

echo 'Build'
grunt build

echo 'Iniciando a aplicação'
pm2 start index.js --name eficiencia
