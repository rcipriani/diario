var ExtractTextPlugin = require('extract-text-webpack-plugin');

module.exports = [
	{
		test: /\.js?$/,
		exclude: /(node_modules|server|public)/,
		loaders: ['react-hot']
	},
	{
		test: /\.js?$/,
		exclude: /(node_modules|server|public)/,
		loader: 'babel',
		query: {
		  presets: ['es2015', 'react'],
		  plugins: ['transform-runtime', 'transform-decorators-legacy', 'transform-class-properties', 'transform-object-rest-spread'],
		}
	},
	// { test: /\.((woff2?|svg)(\?v=[0-9]\.[0-9]\.[0-9]))|(woff2?|svg|jpe?g|png|gif|ico)$/, loader: 'url?limit=10000' },
	// { test: /\.((ttf|eot)(\?v=[0-9]\.[0-9]\.[0-9]))|(ttf|eot)$/, loader: 'file' },
	{ test: /.(png|woff(2)?|eot|ttf|svg)(\?[a-z0-9=\.]+)?$/, loader: 'url-loader?limit=100000' },
	// {
	// 	test: /\.eot(\?v=\d+\.\d+\.\d+)?$/,
	// 	exclude: /(node_modules|server)/,
	// 	loader: "file"
	// },
	// {
	// 	test: /\.(woff|woff2)$/,
	// 	exclude: /(node_modules|server)/,
	// 	loader: "url?prefix=font/&limit=5000"
	// },
	// {
	// 	test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/,
	// 	exclude: /(node_modules|server)/,
	// 	loader: "url?limit=10000&mimetype=application/octet-stream"
	// },
	{
		test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
		exclude: /(node_modules|server)/,

		loader: "url?limit=10000&mimetype=image/svg+xml"
	},
	{
		test: /\.gif/,
		exclude: /(node_modules|server)/,
		loader: "url-loader?limit=10000&mimetype=image/gif"
	},
	{
		test: /\.jpg/,
		exclude: /(node_modules|server)/,
		loader: "url-loader?limit=10000&mimetype=image/jpg"
	},
	{
		test: /\.png/,
		exclude: /(node_modules|server)/,
		loader: "url-loader?limit=10000&mimetype=image/png"
	},
	// {
	// 	test: /\.scss$/,
	// 	loader: "style-loader!css-loader!sass-loader"
	// },
	// {
	// 	test: /\.scss$/,
	// 	loader: 'style!css!sass'
	// }
	// {
	// 	test: /(\.scss|\.css)$/,
	// 	loader: ExtractTextPlugin.extract('style', 'css?sourceMap&modules&importLoaders=1&localIdentName=[name]__[local]___[hash:base64:5]!postcss!sass')
	// }
];
