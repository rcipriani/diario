var webpack = require('webpack');
var path = require('path');
var loaders = require('./webpack.loaders.js');
var HtmlWebpackPlugin = require('html-webpack-plugin');

// configure defaults
var serverConfig = {
    port: 3008, // porta padrão
    maxAge: 1000 * 30 * 60
}

try {
    serverConfigLoader = require('./src/config/server-config.json');
    Object.assign(serverConfig, serverConfigLoader);
} catch (e) {
    if (e instanceof Error && e.code === "MODULE_NOT_FOUND")
        console.log("Arquivo de configuração do server não encontrado!");
    else
        throw e;
}

const HOST = process.env.HOST || 'localhost.bb.com.br';
const PORT = process.env.PORT || serverConfig.port;

// global css
loaders.push({
	test: /[\/\\](node_modules|global)[\/\\].*\.css$/,
	loaders: [
		'style?sourceMap',
		'css'
	]
});
// local scss modules
loaders.push({
	test: /[\/\\]src[\/\\].*\.scss/,
	exclude: /(node_modules|server|public)/,
	loaders: [
		'style?sourceMap',
		'css?modules&importLoaders=1&localIdentName=[path]___[name]__[local]___[hash:base64:5]',
		'sass'
	]
});

// CARREGAR OS SCSS DO REACT-TOOLBOX
loaders.push({
	test: /[\/\\]node_modules\/react-toolbox[\/\\].*\.scss/,
	exclude: /(server|public)/,
	loaders: [
		'style?sourceMap',
		'css?modules&importLoaders=1&localIdentName=[path]___[name]__[local]___[hash:base64:5]',
		'sass'
	]
});

// local css modules
loaders.push({
	test: /[\/\\]src[\/\\].*\.css/,
	exclude: /(node_modules|server|public)/,
	loaders: [
		'style?sourceMap',
		'css?modules&importLoaders=1&localIdentName=[path]___[name]__[local]___[hash:base64:5]'
	]
});


module.exports = {
	entry: [
		`webpack-dev-server/client?http://${HOST}:${PORT}`,
		`webpack/hot/only-dev-server`,
		`./src/index.js` // Your appʼs entry point
	],
	// devtool: process.env.WEBPACK_DEVTOOL || 'cheap-module-source-map',
  devtool: 'eval-source-map',
	output: {
		path: path.join(__dirname, 'public'),
        filename: 'bundle.js',
        publicPath: "/"
	},
    resolve: {
        root: [
            path.join(__dirname, './src'),
            path.join(__dirname, './node_modules'),
            // path.join(__dirname, 'src/node_modules'),
			path.join(__dirname, './', 'common'),
			path.join(__dirname, './src/assets'),
			// path.join(__dirname, '/../', 'common') // retirar este e colocar a elements neste projeto
        ],
        extensions: ['', '.js'],
    },
	module: {
		loaders
	},
	devServer: {
		contentBase: "./public",
		// do not print bundle build stats
		noInfo: true,
		// enable HMR
		hot: true,
		// embed the webpack-dev-server runtime into the bundle
		inline: true,
		// serve index.html in place of 404 responses to allow HTML5 history
		historyApiFallback: true,
		port: PORT,
		host: HOST
	},
	plugins: [
		new webpack.NoErrorsPlugin(),
		new webpack.HotModuleReplacementPlugin(),
        new webpack.DefinePlugin({
            'process.env': {
                'AMBIENTE': JSON.stringify(process.env.AMBIENTE)
            }
        }),
		new HtmlWebpackPlugin({
			template: './src/index.html'
		}),
	]
};
