/**
 * Created by thiago on 26/10/2016.
 */

'use strict';

module.exports = function (app) {


    var PbmsModel           = app.models.modelo.pbms,
        service             = {};


    service.incluirLote        = function (dados) {

        return PbmsModel.bulkCreate(dados);
    };

    service.consultar        = function (dados) {

        return PbmsModel.findAll(
        //     {
        //     where : {'TPO_PBMS' : dados}
        // }
        );
    };

    return service;
};
