/**
 * Created by thiago on 27/10/2016.
 */

'use strict';

module.exports = function (app) {


    var DadosInformacaoModel  = app.models.modelo.dadosInformacao,
        service               = {};


    service.atualizarUltimaAtualizacao = function (codigoInformacao, dataAtualizacao) {
        console.log("vai atualizar", codigoInformacao, dataAtualizacao);
        var dados = {
            'ts_ult_alt' : dataAtualizacao
        };

        return DadosInformacaoModel.update(dados,
            {where: {
                "cd_inf"     : codigoInformacao
            }
        });

    };

    service.recuperarInformacao  = function (codigoInformacao) {

        return DadosInformacaoModel.find(
             {
             where: {'cd_inf': codigoInformacao},
             attributes: ['cd_inf', 'vl_frq_alt', 'ts_ult_alt' , 'in_atl_atv']
         }
        );
    };

    service.recuperarInformacoes = function (codigosInformacao) {

        return DadosInformacaoModel.findAll(
            {
                where: {'cd_inf': {$in: codigosInformacao}},
                order: ['cd_inf']
            }
        );
    };

    return service;
};