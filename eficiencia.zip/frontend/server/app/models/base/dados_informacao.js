module.exports = function (sequelize, DataTypes) {


    var dadosInformacao = sequelize.define('dadosInformacao', {

            cd_inf: {
                type: DataTypes.INTEGER,
                underscored: true,
                allowNull: false,
                primaryKey: true
            },
            in_atl_atv: {
                type: DataTypes.BOOLEAN,
                underscored: true,
                allowNull: false
            },
            vl_frq_alt: {
                type: DataTypes.DECIMAL(7, 4),
                underscored: true,
                allowNull: false,
                primaryKey: false
            },
            ts_ult_alt: {
                type: DataTypes.DATE,
                underscored: true,
                allowNull: false
            },
            ts_alt: {
                type: DataTypes.DATE,
                underscored: true,
                allowNull: false,
                defaultValue: DataTypes.NOW
            }
        },
        {
            schema: 'base',
            tableName: 'dado_inf_atzd',
            freezeTableName: true,
            classMethods: {}
        });

    return dadosInformacao;
};