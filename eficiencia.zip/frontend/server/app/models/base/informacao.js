module.exports = function (sequelize, DataTypes) {


    var informacao = sequelize.define('informacao', {

            cd_inf: {
                type: DataTypes.INTEGER,
                underscored: true,
                allowNull: false,
                autoIncrement: true,
                primaryKey: true
            },
            dcr_inf: {
                type: DataTypes.STRING(100),
                underscored: true,
                allowNull: false,
                primaryKey: false
            },
            ts_alt: {
                type: DataTypes.DATE,
                underscored: true,
                allowNull: false,
                defaultValue: DataTypes.NOW
            }
        },
        {
            schema: 'base',
            tableName: 'informacao',
            freezeTableName: true,
            classMethods: {}
        });

    return informacao;
};