module.exports = function (sequelize, DataTypes) {


    var pbms = sequelize.define('pbms', {

        TPO_PBMS: {
            type: DataTypes.INTEGER,
            underscored: true,
            allowNull: false,
            primaryKey: true
        },
        CLS_PBMS: {
            type: DataTypes.INTEGER,
            underscored: true,
            allowNull: false,
            primaryKey: true
        },
        SCL_PBMS: {
            type: DataTypes.INTEGER,
            underscored: true,
            allowNull: false,
            primaryKey: true
        },
        SEQ_PBMS: {
            type: DataTypes.INTEGER,
            underscored: true,
            allowNull: false,
            primaryKey: true
        },
        CD_SIS_OGM: {
            type: DataTypes.INTEGER,
            underscored: true,
            allowNull: false,
            primaryKey: true
        },
        NOM_ITEM: {
            type: DataTypes.STRING(50),
            underscored: true,
            allowNull: true
        },
        IND_BASE: {
            type: DataTypes.INTEGER,
            allowNull: true,
            underscored: true
        },
        CD_TIP_ITEM: {
            type: DataTypes.INTEGER,
            underscored: true,
            allowNull: true
        }
    },
        {
        schema   : 'contrato',
        tableName: 'pbms',
        freezeTableName: true,
        classMethods: {
        }
    });

    return pbms;
};