var moment = require('moment');
moment.locale('pt-br');

var MomentHelper = moment;

export default MomentHelper;
