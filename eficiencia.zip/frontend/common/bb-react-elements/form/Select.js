import React from 'react';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';

const Select = ({...props, children, href, itens, labelText}) => (

    <SelectField {...props} floatingLabelStyle={style.label} >
        {itens && itens.map(item => (
            <MenuItem value={item.value} primaryText={item.primaryText} key={item.key} />
        ))}
    </SelectField>
);

const style = {
    label: {
        fontSize: '1.5em',
        color: '#666'
    }
};

export default Select;
