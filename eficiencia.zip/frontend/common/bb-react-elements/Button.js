import React from 'react';


var Button = React.createClass({

    propTypes: {
        children: React.PropTypes.string.isRequired,
        type: React.PropTypes.string.isRequired
    },

    getDefaultProps: function () {
        return {
            type: 'button'
        };
    },

    componentDidMount: function () {
        // console.log('TESTE', Array.isArray(this.props.children));
        // console.log(this.props.children);
    },

    render: function () {
        return (
            <button {...this.props} className="waves-effect waves-light blue darken-1 btn">
                {this.props.children}
            </button>
        );
    }
});

export default Button