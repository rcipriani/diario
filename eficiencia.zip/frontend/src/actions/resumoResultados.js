import * as types from 'actions/actionTypes';
import { createAction } from 'actions';
import api  from 'lib/api';

export const buscaResumoResultados = () => {

    return createAction(types.BUSCA_RESUMO_RESULTADOS, api.get('/processo/indicadorResultadoProcesso/resultado/processo/12meses'));

};

export const buscaDetalheIndicador = (indicadorId) => {

    return createAction(types.BUSCA_DETALHE_INDICADOR, api.get('/processo/indicador/consultar/' + indicadorId));

};

export const buscaOcorrenciaResultado = (codigoProcesso, codigoIndicador, ano, mes) => {
    // 1/1/2016/10
    // return createAction(types.BUSCA_OCORRENCIA_RESULTADO,
    //     api.get(`/processo/ocorrenciaResultadoProcesso/ocorrencia/1/1/2016/10`));

    return createAction(types.BUSCA_OCORRENCIA_RESULTADO,
        api.get(`/processo/ocorrenciaResultadoProcesso/ocorrencia/${codigoProcesso}/${codigoIndicador}/${ano}/${mes}`));

};