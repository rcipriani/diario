/**
 * Created by f9329476 on 27/01/2017.
 */
import * as types from 'actions/actionTypes';
import { createAction } from 'actions';
import api  from 'lib/api';

export const BUSCA_INDICADORES_PROCESSO         = 'BUSCA_INDICADORES_PROCESSO';
export const BUSCA_INDICADORES_PROCESSO_SUCCESS = 'BUSCA_INDICADORES_PROCESSO_SUCCESS';
export const BUSCA_INDICADORES_PROCESSO_LOADING = 'BUSCA_INDICADORES_PROCESSO_LOADING';
export const BUSCA_INDICADORES_PROCESSO_FAILURE = 'BUSCA_INDICADORES_PROCESSO_FAILURE';

export const listarIndicadoresProcessos = () => {
    return createAction(BUSCA_INDICADORES_PROCESSO, api.get('/processo/indicadorVinculadoProcesso/consultar/todos'));
};
