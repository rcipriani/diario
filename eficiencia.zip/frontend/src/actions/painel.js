import api from 'lib/api';
import { createAction } from 'actions';
import * as types from './actionTypes';

export const buscaDadosAnaliticoProcessos = (params) => {

    return createAction(types.BUSCA_ANALITICO_PROCESSOS, api.get('/projeto/relatorio/painelEficiencia/busca/analitico/processos', { params: params }));
};

export const buscaDadosSinteticoAcoes = (params) => {

    return createAction(types.BUSCA_SINTETICO_ACOES, api.get('/projeto/relatorio/painelEficiencia/busca/sintetico/processos', { params: params }));
};

export const buscaDadosSinteticoProcessos = (params) => {

    return createAction(types.BUSCA_SINTETICO_PROCESSOS, api.get('/projeto/relatorio/painelEficiencia/busca/sintetico/processos', { params: params }));
};

export const buscaDadosSinteticoAcoesEtapaAtraso = (params) => {

    return createAction(types.BUSCA_SINTETICO_ACOES_ETAPAS_ATRASO, api.get('/projeto/relatorio/painelEficiencia/busca/sintetico/acoesEtapas/atraso', { params: params }));

};

export const buscaEtapasAtrasoAnalitico = (params, sequencias) => {

    return createAction(types.BUSCA_ANALITICO_ETAPAS_ATRASO, api.get('/projeto/relatorio/painelEficiencia/busca/analitico/tarefas', { params: { ...params, acao : 1 } }), {...params, sequencias});


};

export const buscaEtapasAtrasoAnaliticoCache = (sequencias) => {

    return dispatch => dispatch(
        { type: types.BUSCA_ANALITICO_ETAPAS_ATRASO_CACHE, sequencias }
    )

};

export const buscaProjeto = (projetoId) => {

    return createAction(types.BUSCA_PROJETO, api.get('/projeto/projeto/' + projetoId));

};

export const recolheEtapasAtrasoAnalitico = (tarefa, posicao) => {

    return dispatch => dispatch(
        { type: types.RECOLHE_ANALITICO_ETAPAS_ATRASO, tarefa, posicao}
    )
};

export const expandeEtapasAtrasoAnalitico = (tarefa, posicao) => {

    return dispatch => dispatch(
        { type: types.EXPANDE_ANALITICO_ETAPAS_ATRASO, tarefa, posicao }
    )
};