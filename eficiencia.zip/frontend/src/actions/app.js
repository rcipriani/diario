import api from 'lib/api';
import {createAction} from 'actions';
import * as types from './actionTypes';

export const buscaUsuarioLogado = () => {
    return createAction(types.BUSCA_USUARIO, api.get('portal/sessao/usuario'));
};

export const buscaUors = (params) => {
    return createAction(types.BUSCA_UOR, api.get('/uor/uor/busca', {params : params}));
};

export const setDadosContextoFrente = (params) => {
    return dispatch => dispatch({
        type: types.SET_DADOS_CONTEXTO_FRENTE, ...params
    })
};

export const toggleModoApresentacao = (params) => {
    return dispatch => dispatch({
        type: types.TOGGLE_MODO_APRESENTACAO, ...params
    })
};

