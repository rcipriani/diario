import store from '../store';
import {buscaDadosSinteticoProcessos, buscaDadosAnaliticoProcessos, buscaProjeto} from '../actions/painel';
import {buscaEtapasIniciadas, buscaEtapasCanceladas} from '../actions/etapas';
import {listarIndicadoresProcessos} from '../actions/indicadoresProcessos';
import { setDadosContextoFrente } from '../actions/app';
import * as resumoResultadoActions from '../actions/resumoResultados';
import {TAREFA_COMPRAS_CONTRATACOES_ID, FRENTE_PROCESSOS_PROJETO_ID, FRENTE_DESPESAS_PROJETO_ID } from 'constants';


const paramsProcessos = { projetoId: FRENTE_PROCESSOS_PROJETO_ID, tarefaId: TAREFA_COMPRAS_CONTRATACOES_ID };
const paramsDespesas = { projetoId: FRENTE_DESPESAS_PROJETO_ID, tarefaId: TAREFA_COMPRAS_CONTRATACOES_ID };

export const app = {

    onAppEnter: (nextState, replace, callback) => {

        console.debug('init app!');
        store.dispatch(setDadosContextoFrente(paramsProcessos));

        callback();
    },

    onIndicadoresEnter: (nextState, replace, callback) => {
        store.dispatch(listarIndicadoresProcessos());
        callback();
    }

};

export const despesas = {

    onPainelEnter: (nextState, replace, callback) => {

        store.dispatch(buscaDadosSinteticoProcessos(paramsDespesas));
        store.dispatch(buscaDadosAnaliticoProcessos(paramsDespesas));
        store.dispatch(buscaProjeto(FRENTE_DESPESAS_PROJETO_ID));

        callback();
    },


    onEtapasIniciadasEnter: (nextState, replace, callback) => {
        store.dispatch(buscaEtapasIniciadas(paramsDespesas));
        callback();
    },

    onEtapasCanceladasEnter: (nextState, replace, callback) => {
        store.dispatch(buscaEtapasCanceladas(paramsDespesas));
        callback();
    },

    onResumoResultadosEnter: (nextState, replace, callback) => {

        store.dispatch(resumoResultadoActions.buscaResumoResultados());

        callback();

    },

};
export const processos = {

    onPainelEnter: (nextState, replace, callback) => {

        store.dispatch(buscaDadosSinteticoProcessos(paramsProcessos));
        store.dispatch(buscaDadosAnaliticoProcessos(paramsProcessos));
        store.dispatch(buscaProjeto(FRENTE_PROCESSOS_PROJETO_ID));

        callback();
    },


    onEtapasIniciadasEnter: (nextState, replace, callback) => {
        store.dispatch(buscaEtapasIniciadas(paramsProcessos));
        callback();
    },

    onEtapasCanceladasEnter: (nextState, replace, callback) => {
        store.dispatch(buscaEtapasCanceladas(paramsProcessos));
        callback();
    },

    onResumoResultadosEnter: (nextState, replace, callback) => {

        store.dispatch(resumoResultadoActions.buscaResumoResultados());

        callback();

    },


};
