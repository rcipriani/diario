import React from 'react';
import { render } from 'react-dom';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';

import App from 'containers/App';
import { APP_URL } from 'config';

import Etapas from 'containers/comprasContratacoes/processos/Etapas';
import EtapasIniciadas from 'containers/comprasContratacoes/processos/EtapasIniciadas';
import EtapasCanceladas from 'containers/comprasContratacoes/processos/EtapasCanceladas';
import Geral from 'containers/comprasContratacoes/processos/Geral';
import Painel from 'containers/comprasContratacoes/processos/Painel';
import Resultados from 'containers/comprasContratacoes/processos/Resultados';
import IndicadoresProcessos from 'containers/comprasContratacoes/IndicadoresProcessos';
import ResumoResultados from 'containers/comprasContratacoes/processos/ResumoResultados';
import  * as callbacks from 'routes/callbacks';


const comprasContratacoes = `${APP_URL}/comprasContratacoes/`;
const comprasContratacoesProcessos = `${comprasContratacoes}processos/`;
const comprasContratacoesDespesas = `${comprasContratacoes}despesas/`;

export const routeCodes = {
    COMPRAS_CONTRATACOES_PROCESSOS_PAINEL: `${comprasContratacoesProcessos}painel`,
    COMPRAS_CONTRATACOES_PROCESSOS_ETAPAS: `${comprasContratacoesProcessos}etapas`,
    COMPRAS_CONTRATACOES_PROCESSOS_RESUMO_RESULTADOS: `${comprasContratacoesProcessos}resumo-resultados`,
    COMPRAS_CONTRATACOES_PROCESSOS_ETAPAS_INICIADAS: `${comprasContratacoesProcessos}etapas/iniciadas`,
    COMPRAS_CONTRATACOES_PROCESSOS_ETAPAS_CANCELADAS: `${comprasContratacoesProcessos}etapas/canceladas`,
    COMPRAS_CONTRATACOES_PROCESSOS_GERAL: `${comprasContratacoesProcessos}geral`,
    COMPRAS_CONTRATACOES_PROCESSOS_RESULTADOS: `${comprasContratacoesProcessos}resultados`,

    COMPRAS_CONTRATACOES_DESPESAS_PAINEL: `${comprasContratacoesDespesas}painel`,
    COMPRAS_CONTRATACOES_DESPESAS_ETAPAS: `${comprasContratacoesDespesas}etapas`,
    COMPRAS_CONTRATACOES_DESPESAS_RESUMO_RESULTADOS: `${comprasContratacoesDespesas}resumo-resultados`,
    COMPRAS_CONTRATACOES_DESPESAS_ETAPAS_INICIADAS: `${comprasContratacoesDespesas}etapas/iniciadas`,
    COMPRAS_CONTRATACOES_DESPESAS_ETAPAS_CANCELADAS: `${comprasContratacoesDespesas}etapas/canceladas`,
    COMPRAS_CONTRATACOES_DESPESAS_GERAL: `${comprasContratacoesDespesas}geral`,
    COMPRAS_CONTRATACOES_DESPESAS_RESULTADOS: `${comprasContratacoesDespesas}resultados`,

    COMPRAS_CONTRATACOES_INDICADORES: `${comprasContratacoes}indicadores`,
};

const RouterApp = () => {
    return (
        <Router history={browserHistory} key={Math.random()} >
            <Route path={(APP_URL == '' ? APP_URL + '/' : APP_URL)} component={App} onEnter={callbacks.app.onAppEnter} >

                <IndexRoute component={Painel} onEnter={callbacks.processos.onPainelEnter} />

                <Route path={routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_PAINEL} component={Painel} onEnter={callbacks.processos.onPainelEnter} />
                <Route path={routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_ETAPAS} component={Etapas} />
                <Route path={routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_RESUMO_RESULTADOS} component={ResumoResultados} onEnter={callbacks.processos.onResumoResultadosEnter} />
                <Route path={routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_ETAPAS_INICIADAS} component={EtapasIniciadas} onEnter={callbacks.processos.onEtapasIniciadasEnter} />
                <Route path={routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_ETAPAS_CANCELADAS} component={EtapasCanceladas} onEnter={callbacks.processos.onEtapasCanceladasEnter} />
                {/*<Route path={routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_GERAL} component={Geral} />*/}
                <Route path={routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_RESULTADOS} component={Resultados} />

                <Route path={routeCodes.COMPRAS_CONTRATACOES_DESPESAS_PAINEL} component={Painel} onEnter={callbacks.despesas.onPainelEnter} />
                {/*<Route path={routeCodes.COMPRAS_CONTRATACOES_DESPESAS_ETAPAS} component={Etapas} />*/}
                <Route path={routeCodes.COMPRAS_CONTRATACOES_DESPESAS_RESUMO_RESULTADOS} component={ResumoResultados} onEnter={callbacks.despesas.onResumoResultadosEnter} />
                <Route path={routeCodes.COMPRAS_CONTRATACOES_DESPESAS_ETAPAS_INICIADAS} component={EtapasIniciadas} onEnter={callbacks.despesas.onEtapasIniciadasEnter} />
                <Route path={routeCodes.COMPRAS_CONTRATACOES_DESPESAS_ETAPAS_CANCELADAS} component={EtapasCanceladas} onEnter={callbacks.despesas.onEtapasCanceladasEnter} />
                {/*<Route path={routeCodes.COMPRAS_CONTRATACOES_DESPESAS_GERAL} component={Geral} />*/}
                <Route path={routeCodes.COMPRAS_CONTRATACOES_DESPESAS_RESULTADOS} component={Resultados} />

                <Route path={routeCodes.COMPRAS_CONTRATACOES_INDICADORES} component={IndicadoresProcessos} onEnter={callbacks.app.onIndicadoresEnter} />
            </Route>
        </Router>
    );
};

export default RouterApp;