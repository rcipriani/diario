/**
 * Created by f9329476 on 23/01/2017.
 */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import _ from 'lodash';

import Quadro from 'components/Quadro';
import Secao from 'components/Secao';

class IndicadoresProcessos extends Component {

    constructor(props) {
        super(props);

    }

    render() {

        const {indicadoresProcessos} = this.props;

        console.log('indicadores', indicadoresProcessos);

        let montarLista = (indicadoresProcessos) => {
            if(indicadoresProcessos){
                return indicadoresProcessos.map((dados, index) => {
                    return (
                        <tr key={index}>
                            <td>{dados.processo.nomeProcesso}</td>
                            <td>{dados.indicador.nomeIndicador}</td>
                            <td>{dados.indicador.formaCalculoIndicador}</td>
                            <td>{dados.indicador.unidadeMedidaIndicador}</td>
                            <td>{_.capitalize(dados.indicador.periodicidade.descricaoPeriodicidade)}</td>
                            <td>{dados.indicador.descricaoIndicador}</td>
                            <td>{dados.indicadorDesempenho ?
                                <i className="fa fa-arrow-up" aria-hidden="true"></i>
                                : <i className="fa fa-arrow-down" aria-hidden="true"></i>}
                            </td>
                            <td>{dados.indicador.informacoesAdicionais}</td>
                        </tr>
                    );
                });
            }else{
                return "";
            }
        };

        return (
            <Secao titulo="Indicadores">

                <Quadro>

                    <table className="bordered highlight responsive-table">
                        <thead>
                        <tr>
                            <th data-field="nomeIndicador">Processo</th>
                            <th data-field="descricaoIndicador">Indicador</th>
                            <th data-field="formaCalculoIndicador">Forma de cálculo</th>
                            <th data-field="unidadeMedidaIndicador">Unidade de medida</th>
                            <th data-field="periodicidadeIndicador">Periodicidade</th>
                            <th data-field="indicadorDesempenho">Descrição</th>
                            <th data-field="indicadorDesempenho">Desempenho</th>
                            <th data-field="indicadorDesempenho">Informações Adicionais</th>
                        </tr>
                        </thead>
                        <tbody>
                        { this.props.details ? null : montarLista(indicadoresProcessos) }
                        </tbody>
                    </table>

                </Quadro>

            </Secao>
        );
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        indicadoresProcessos: state.indicadoresProcessos,
    }
};

export default connect(
    mapStateToProps
)(IndicadoresProcessos);
