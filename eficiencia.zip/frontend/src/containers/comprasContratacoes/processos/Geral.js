import React, {Component} from 'react';
import {connect} from 'react-redux';
import _ from 'lodash';

class Geral extends Component {

    state = {};

    constructor(props) {
        super(props);

    }

    componentDidMount() {
        $(document).ready(function () {

            $('.collapsible').collapsible({
                accordion: false // A setting that changes the collapsible behavior to expandable instead of the default accordion style
            });
            $('select').material_select();

        });
    }

    render() {

        const {} = this.props;
        const {} = this.state;

        return (
            <div className="container">

                <div className="row">
                    <h3 className="col s12 header white-text">Acompanhamento das Ações</h3>
                </div>

                <div className="row">
                    <div className="col s12">
                        <ul className="collapsible z-depth-1" data-collapsible="expandable">
                            <li>
                                <div className="collapsible-header active">
                                    <span className="blue-text"
                                          style={{fontSize: '1.5rem'}}>Compras e Contratações </span>
                                </div>
                                <div className="collapsible-body white" style={{display: 'block'}}>
                                    <div className="row">
                                        <div className="col s12">
                                            Painel Geral
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        dadosProcessosComprasContratacoes: state.painel.dadosProcessosComprasContratacoes
    }
};

export default connect(
    mapStateToProps
)(Geral);