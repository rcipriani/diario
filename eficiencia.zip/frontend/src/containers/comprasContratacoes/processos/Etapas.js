import React, {Component} from 'react';
import {STATIC_SERVER_URL} from 'config';

import PaginasEstaticas from 'components/PaginasEstaticas';

class Etapas extends Component {

    render() {

        const blocos = [
            {header: 'Gerir Contratos - Rafaela Queiroz', imagem: `${STATIC_SERVER_URL}/imgs/eficiencia/etapas-gerircontratos.png`},
            {header: 'Realizar Pagamento - Zé Newton', imagem: `${STATIC_SERVER_URL}/imgs/eficiencia/etapas-realizarpagamentos.png`},
            {header: 'Realizar Pagamento - Robson Alves (Desenvolver)', imagem: `${STATIC_SERVER_URL}/imgs/eficiencia/etapas-realizarpagamentos2.png`},
            {header: 'Realizar Pagamento - Robson Alves (Implantar)', imagem: `${STATIC_SERVER_URL}/imgs/eficiencia/etapas-realizarpagamentos3.png`},
            {header: 'Realizar Pagamento - Sandra Barros', imagem: `${STATIC_SERVER_URL}/imgs/eficiencia/etapas-realizarpagamentos4.png`},
            {header: 'Etapas Já Iniciadas', imagem: `${STATIC_SERVER_URL}/imgs/eficiencia/etapas-jainiciadas.png`},
            {header: 'Etapas Canceladas', imagem: `${STATIC_SERVER_URL}/imgs/eficiencia/etapas-canceladas.png`}


        ];

        return (
            <div className="">

                <div className="row">
                    <h3 className="col s12 header white-text">Processos - Etapas</h3>
                </div>

                <div className="row">
                    <PaginasEstaticas blocos={blocos} />
                </div>
            </div>
        );
    }
}

export default Etapas;
