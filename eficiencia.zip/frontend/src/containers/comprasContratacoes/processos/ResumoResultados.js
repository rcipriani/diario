﻿import React, { Component } from 'react';
import { connect } from 'react-redux';

import Secao from 'components/Secao';
import Quadro from 'components/Quadro';
import TabelaResumoResultados from 'components/TabelaResumoResultados';
import {buscaDetalheIndicador, buscaOcorrenciaResultado} from 'actions/resumoResultados';

class ResumoResultados extends Component {

    handleClickDetalheIndicador(indicador) {
        console.debug('handleclickdetalhe', indicador);
        this.props.dispatch(buscaDetalheIndicador(indicador.id));
    }

    handleClickDetalhePendencia(codigoProcesso, codigoIndicador, ano, mes) {
        console.debug('handleClickDetalhePendencia', codigoProcesso, codigoIndicador, ano, mes);
        this.props.dispatch(buscaOcorrenciaResultado(codigoProcesso, codigoIndicador, ano, mes));
    }

    render() {

        const {periodos, processos, detalheIndicador, detalhePendencia, modoApresentacao} = this.props;
        
        return (

            <Secao titulo="Resumo dos Resultados">

                <Quadro>

                    <TabelaResumoResultados
                        processos={processos}
                        periodos={periodos}
                        detalheIndicador={detalheIndicador}
                        detalhePendencia={detalhePendencia}
                        onClickDetalheIndicador={this.handleClickDetalheIndicador.bind(this)}
                        onClickDetalhePendencia={this.handleClickDetalhePendencia.bind(this)}
                        modoApresentacao={modoApresentacao}
                    />

                </Quadro>

            </Secao>

        )
    }
}


const mapStateToProps = (state, ownProps) => {
    return {
        periodos: state.resumoResultados.periodos,
        processos : state.resumoResultados.processos,
        detalheIndicador : state.resumoResultados.detalheIndicador,
        detalhePendencia : state.resumoResultados.detalhePendencia,
        modoApresentacao: state.app.modoApresentacao
    }
};

export default connect(
    mapStateToProps
)(ResumoResultados);

