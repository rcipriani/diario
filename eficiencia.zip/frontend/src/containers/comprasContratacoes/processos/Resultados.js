import React, {Component} from 'react';
import {STATIC_SERVER_URL} from 'config';

import PaginasEstaticas from 'components/PaginasEstaticas';

class Resultados extends Component {

    render() {

        const blocos = [
            {header: 'Indicadores', imagem: `${STATIC_SERVER_URL}/imgs/eficiencia/resultados-indicadores.png`}


        ];

        return (

            <Secao titulo="Processos - Etapas">

                <div className="row">
                    <PaginasEstaticas blocos={blocos} />
                </div>
            
            </Secao>
        );
    }
}

export default Resultados;
