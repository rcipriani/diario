﻿import React, { Component } from 'react';
import { connect } from 'react-redux';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';

import TabelaEtapas from 'components/TabelaEtapas';
import Quadro from 'components/Quadro';
import Aviso from 'components/Aviso';
import Secao from 'components/Secao';
import * as etapasActions from 'actions/etapas';

class EtapasCanceladas extends Component {

    componentDidMount() {

        this.params = {
            projetoId: this.props.projetoId,
            tarefaId: this.props.tarefaId,
        }
    }

    componentDidUpdate(a, b){
        console.log('aaa', a, b);
    }

    handleClickExpansor(dado, indice) {


        let params = this.lastParams || this.params;

        if (dado.expandido) {
            this.props.dispatch(etapasActions.recolheEtapas(dado));
        } else {
            this.props.dispatch(etapasActions.expandeEtapas(dado, indice));
        }

        this.lastParams = params;

    }


    render() {

        const {etapas} = this.props;

        return (
            <Secao titulo="Etapas Canceladas">
                <Quadro>
                    {etapas.length > 0 ?
                        <TabelaEtapas
                            etapas={etapas}
                            onClickExpansor={this.handleClickExpansor.bind(this)}
                            showTerminoPrevisto={false}
                        />
                        :
                        <Aviso>Não há etapas canceladas</Aviso>
                    }
                </Quadro>
            </Secao>
        );
    }
}

// {dadosAnaliticoTarefasAtraso.length && <Quadro>

const mapStateToProps = (state, ownProps) => {

    return {
        etapas   : state.etapas.etapas,
        projetoId: state.app.projetoId,
        tarefaId : state.app.tarefaId
    }
};

export default connect(
    mapStateToProps
)(EtapasCanceladas);
