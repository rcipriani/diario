﻿import React, { Component } from 'react';
import { connect } from 'react-redux';
import Select from 'bb-react-elements/form/Select';

import TabelaEtapas from 'components/TabelaEtapas';
import Quadro from 'components/Quadro';
import Aviso from 'components/Aviso';
import Secao from 'components/Secao';
import * as etapasActions from 'actions/etapas';

const periodos = [
    {
        id: 0,
        dias: 7
    },
    {
        id: 1,
        dias: 15
    },
    {
        id: 2,
        dias: 30
    },
    {
        id: 3,
        dias: 90
    },
    {
        id: 4,
        dias: 180
    },
];

class EtapasIniciadas extends Component {

    state = {
        periodo: periodos[0]
    };

    componentDidMount() {

        this.params = {
            projetoId: this.props.projetoId,
            tarefaId: this.props.tarefaId,
            projecaoDias: periodos[0].dias
        }
    }


    handleClickExpansor(dado) {

        let params = this.lastParams || this.params;

        if (dado.expandido) {
            this.props.dispatch(etapasActions.recolheEtapas(dado));
        } else {
            if (dado.carregado) {
                this.props.dispatch(etapasActions.expandeEtapas(dado));
            } else {
                params = { ...params, tarefaId: dado.tarefa.id };
                this.props.dispatch(etapasActions.buscaEtapasIniciadas(params, { dado: dado }));
            }
        }

        this.lastParams = params;

    }

    handleChangePeriodo(event, key, id) {

        let periodo = periodos.filter(periodo => periodo.id == id)[0];

        this.setState({
            periodo: periodo
        });

        let params = { ...this.params, projecaoDias: periodo.dias };

        this.props.dispatch(etapasActions.buscaEtapasIniciadas(params));

        this.lastParams = params;
    }

    render() {

        const {etapas} = this.props;

        return (
            <Secao titulo="Etapas Iniciadas">

                <Quadro>

                    <Select
                        floatingLabelText="Prazo de término"
                        value={this.state.periodo.id}
                        onChange={this.handleChangePeriodo.bind(this)}
                        itens={periodos.map(periodo => {
                            return {
                                value: periodo.id,
                                primaryText: `Pŕoximos ${periodo.dias} dias`,
                                key: periodo.id
                            }
                        })}
                    />

                </Quadro>

                <Quadro>

                    {etapas.length > 0 ?
                        <TabelaEtapas etapasIniciadas={etapas}
                            onClickExpansor={this.handleClickExpansor.bind(this)} />
                        :
                        <Aviso>Não há etapas iniciadas</Aviso>
                    }

                </Quadro>

            </Secao>
        );
    }
}

// {dadosAnaliticoTarefasAtraso.length && <Quadro>

const mapStateToProps = (state, ownProps) => {
    return {
        etapas: state.etapas,
        projetoId: state.app.projetoId,
        tarefaId: state.app.tarefaId
    }
};

export default connect(
    mapStateToProps
)(EtapasIniciadas);
