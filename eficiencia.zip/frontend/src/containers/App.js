import React, {Component} from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import store from 'store';
import {SERVER_BASE_URL, STATIC_SERVER_URL} from 'config';
import {toggleModoApresentacao} from 'actions/app';
import {Loading} from 'bb-react-elements/Loading';
import MenuLateral from 'components/geral/MenuLateral';
import Toast from 'components/Toast';

class App extends Component {

    constructor(props){
        super(props);
    }

    componentDidUpdate(){
        $(".button-collapse").sideNav();
    }

    componentDidMount(){
        $(document).ready(function(){
            $('.tooltipped').tooltip({delay: 50});
        });
    }

    toggleModoApresentacao = () => {
        store.dispatch(toggleModoApresentacao());
    };

    render() {

        const {loading, usuario, modoApresentacao} = this.props;

        return (
            <MuiThemeProvider>
                <div>

                    {/*{loading > 0 &&*/}
                    {/*<div style={{zIndex: '9999', position: 'relative'}}>*/}
                        {/*<Loading />*/}
                    {/*</div>}*/}
                    
                    {usuario &&
                        <div className="row">
                            {/*<a href="#" data-activates="slide-out" className="button-collapse waves-effect waves-light btn">Menu</a>*/}

                            <div className={['main', (modoApresentacao ? 'flow-text' : 'paddingMenu')].join(' ')}>
                                <div className={[(modoApresentacao ? 'paddintMainApresentacao' : 'container')].join(' ')} >
                                    {this.props.children}
                                </div>

                                <div className="fixed-action-btn" style={{zIndex: '9999'}}>
                                    <a className="btn-floating btn-large blue">
                                        <i className="fa fa-bars" aria-hidden="true"></i>
                                    </a>
                                    <ul>
                                        <li>
                                            <a
                                                onClick={() => this.toggleModoApresentacao()}
                                                className="waves-effect waves-light btn-floating blue tooltipped"
                                                data-position="left"
                                                data-delay="50"
                                                data-tooltip="Mode Apresentação">
                                                <i className="fa fa-slideshare" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>

                            </div>

                            <MenuLateral isFixed={!modoApresentacao} usuario={usuario}></MenuLateral>

                        </div>
                    }
                    
                <Toast timeout="180000"/>
                </div>
            </MuiThemeProvider>

        )

    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        modoApresentacao: state.app.modoApresentacao,
        loading: state.app.loading,
        usuario: state.app.usuario
    }
};

export default connect(mapStateToProps)(App);

