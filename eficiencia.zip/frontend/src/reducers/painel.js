import * as types from 'actions/actionTypes';
import update from 'react-addons-update';

const initialState = {

    dadosAnaliticoProcessos: [],
    dadosAnaliticoTarefasAtraso: [],
    dadosSinteticoAcoes: [],
    dadosSinteticoProcessos: [],
    dadosSinteticoAcoesEtapasAtraso: {},
    projeto: {},
};

let acoesOriginais = [];


const painel                 = (state = initialState, action) => {

    let dados          = [];
    let acoesFiltradas = [];

    switch (action.type) {
        case types.BUSCA_ANALITICO_PROCESSOS_SUCCESS:
            return {...state, dadosAnaliticoProcessos: action.payload};
        case types.BUSCA_ANALITICO_ETAPAS_ATRASO_SUCCESS:
            acoesOriginais = action.payload;

            action.payload.forEach(dado => {
                if (dado.nivel == 3) {
                    dado.expandido = false;
                    dado.visivel   = true;
                    dados.push(dado);
                }

            });
            // acoesFiltradas = filtraTarefas(acoesOriginais, action.sequencias);
            return {...state, dadosAnaliticoTarefasAtraso: action.payload};

        case types.BUSCA_ANALITICO_ETAPAS_ATRASO_CACHE:
            acoesFiltradas = filtraTarefas(acoesOriginais, action.sequencias);
            return {...state, dadosAnaliticoTarefasAtraso: acoesFiltradas};
        case types.BUSCA_PROJETO_SUCCESS:
            return {...state, projeto:  (action.payload)};
        case types.BUSCA_SINTETICO_ACOES_SUCCESS:
            return {...state, dadosSinteticoAcoes: converterStatus(action.payload)};
        case types.BUSCA_SINTETICO_PROCESSOS_SUCCESS:
            return { ...state, dadosSinteticoProcessos: converterStatus(action.payload) };
        case types.BUSCA_SINTETICO_ACOES_ETAPAS_ATRASO_SUCCESS:
            return { ...state, dadosSinteticoAcoesEtapasAtraso: action.payload };    
        case types.RECOLHE_ANALITICO_ETAPAS_ATRASO:
            dados = recolher(state.dadosAnaliticoTarefasAtraso, action.tarefa.nivel, action.posicao);
            return {...state, dadosAnaliticoTarefasAtraso: dados};
        case types.EXPANDE_ANALITICO_ETAPAS_ATRASO:
            dados =  verificaExpansaoCache(action.posicao, action.tarefa, state.dadosAnaliticoTarefasAtraso);
            if (!dados) {
                acoesFiltradas = filtraTarefas(acoesOriginais, [action.tarefa.sequencialTarefaEap]);
                dados = expandir(acoesFiltradas, state.dadosAnaliticoTarefasAtraso, action.posicao);
            }
            return {...state, dadosAnaliticoTarefasAtraso: dados};
    }

    return state;

};

const converterStatus        = (dadosSintetico) => {
    return dadosSintetico.map(dado => {
            let descricao;
            switch (dado.status) {
                case 'SEMPRV':
                    descricao = 'Sem Previsão';
                    break;
                case 'IMPVNC':
                    descricao = 'Impactado por Vencimento';
                    break;
                case 'CONPZO':
                    descricao = 'Concluída no Prazo';
                    break;
                case 'CONANT':
                    descricao = 'Concluída antecipadamente';
                    break;
                case 'CONATR':
                    descricao = 'Concluída em Atraso';
                    break;
                default:
                    descricao = 'Em Andamento';
                    break;
            }

            return {
                ...dado,
                descricao,
            }
        }
    )
};

const expandir               = (dadosNovos, dadosAntigos, posicao) => {

    dadosAntigos[posicao].expandido = true;
    dadosAntigos.splice.apply(dadosAntigos, [posicao + 1, 0].concat(dadosNovos));

    return update([], {$push: dadosAntigos});

};

const filtraTarefas          = (acoes, sequenciaisPai) => {

    let dados = [];
    acoes.forEach(dado => {
        if ( sequenciaisPai.indexOf(dado.sequencialTarefaEapPai) >=  0 ) {
            dado.expandido = false;
            dado.visivel   = true;
            dados.push(dado);
        }

    });

    return dados;
};

const recolher               = (dados, nivel, posicao) => {

    dados[posicao].expandido = false;
    let indice = posicao + 1;
    const novoNivel = nivel +1;
    const tamanhoDados = dados.length;
    while (indice < tamanhoDados && dados[indice].nivel >= novoNivel) {
        dados[indice].expandido = false;
        dados[indice].visivel = false;
        indice++;
    }

    return update([], {$push: dados});

};

const verificaExpansaoCache  = (posicao, tarefa, dados) => {
    const tamanhoDados = dados.length;
    let indice = posicao + 1;

    if (indice >= dados.length) return null;
    console.log("posicao", posicao);
    if (dados[posicao].nivel < dados[indice].nivel) {
        let nivel = dados[indice].nivel;
        dados[posicao].expandido = true;
        while (indice < tamanhoDados &&  nivel == dados[indice].nivel) {
            dados[indice].visivel = true;
            indice++;
        }
        return update([], {$push: dados});
    }

    return null;
};


export default painel;

