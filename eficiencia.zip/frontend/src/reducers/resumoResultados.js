import * as types from 'actions/actionTypes';
import _ from 'lodash';

const initialState = {
    processos : [],
    periodos: [],
    detalheIndicador: null,
    detalhePendencia: null
};

const resumoResultados = (state = initialState, action) => {

    switch (action.type) {

        case types.BUSCA_DETALHE_INDICADOR_SUCCESS:

            return { ...state, detalheIndicador: action.payload };

        case types.BUSCA_OCORRENCIA_RESULTADO_SUCCESS:

            return { ...state, detalhePendencia: action.payload };

        case types.BUSCA_RESUMO_RESULTADOS_SUCCESS:

            const dados = action.payload;

            const grupoProcessos = _.groupBy(dados, 'codigoProcesso');

            const processos = Object.keys(grupoProcessos).map(key => {

                const grupoProcesso = grupoProcessos[key];

                const grupoIndicadores = _.groupBy(grupoProcesso, 'codigoIndicador');

                const indicadores = Object.keys(grupoIndicadores).map(keyIndicador => {

                    const grupoApuracao = grupoIndicadores[keyIndicador];

                    const apuracoes = Object.keys(grupoApuracao).map(keyApuracao => {

                        const apuracao = grupoApuracao[keyApuracao];

                        return {
                            ano: apuracao.anoApuracao,
                            mes: apuracao.mesApuracao,
                            meta: apuracao.valorMeta,
                            desvio: apuracao.valorAtingido - apuracao.valorMeta,
                            real: apuracao.valorAtingido,
                        }

                    });

                    return {
                        id : grupoApuracao[0].codigoIndicador,
                        nome: grupoApuracao[0].indicador.nomeReduzidoIndicador,
                        indicadorDesempenho: grupoApuracao[0].indicador.indicadorDesempenho,
                        apuracoes: apuracoes,
                    }

                });

                return {
                    id: grupoProcesso[0].codigoProcesso,
                    nome: grupoProcesso[0].processo.nomeProcesso,
                    indicadores: indicadores
                }
            });

            const periodos = processos[0].indicadores[0].apuracoes;

            return { ...state, processos, periodos }

    }

    return state;
};

export default resumoResultados;