import update from 'react-addons-update';
import * as types from 'actions/actionTypes';

const initialState = {
    // etapasOriginais : [],
    etapas : []
};

let etapasOriginais = [];


const etapas         = (state = initialState, action) => {

    let etapasFiltradas = [];
    let dados           = [];

    switch (action.type) {
        case types.BUSCA_ETAPAS_SUCCESS:
            console.log("passando aqui");
            // initialState.etapasOriginais = action.payload;
            etapasOriginais = action.payload;

            action.payload.forEach(dado => {
                if (dado.nivel == 1) {
                    dado.expandido = false;
                    dado.visivel   = true;
                    dados.push(dado);
                }

            });

            return {...state, etapas: dados};
        case types.RECOLHE_ETAPAS:

            dados = expandeRecolhe(state, action.tarefa, false);

            return dados.concat([0]);

        case types.EXPANDE_ETAPAS:

            etapasFiltradas = filtraTarefas(etapasOriginais, action.tarefa);
            console.log("etapasFiltradas", etapasFiltradas);
            dados = expandir(etapasFiltradas, state.etapas, action.posicao);

            console.log("dados", dados);
            return {...state, etapas: dados};

    }

    return state;

};

const converteDados  = (dados, lastKey, tarefa) => {

    console.log("dados", dados);
    return dados.map((dado, index) => {

        return {
            ...dado,
            paiId    : tarefa ? tarefa.key : null,
            key      : index + (lastKey || 0),
            visivel  : true,
            expandido: false,
            carregado: false,
            nivel: undefined == tarefa ? 0 : tarefa.nivel + 1
        }

    });

};

const expandir = (dadosNovos, dadosAntigos, posicao) => {

    dadosAntigos.splice.apply(dadosAntigos, [posicao + 1, 0].concat(dadosNovos));

    return update([], {$push: dadosAntigos});
    // return dadosAntigos.concat(dadosNovos);

 //   let filhos = dados.filter(dado => dado.paiId == tarefa.key);

   // let tarefaAtual = dados.filter(dado => dado.key == tarefa.key)[0];

};

const expandeRecolhe = (dados, tarefa, expandir) => {

    let filhos = dados.filter(dado => dado.paiId == tarefa.key);

    let tarefaAtual = dados.filter(dado => dado.key == tarefa.key)[0];

    tarefaAtual.expandido = expandir;

    filhos.forEach(filho => {
            filho.visivel = expandir;
            if (filho.pai && !expandir) expandeRecolhe(dados, filho, false);
        }
    );


    return dados;
};

const filtraTarefas  = (etapas, sequencialPai) => {

    let dados = [];

    etapas.forEach(dado => {
        if (dado.sequencialTarefaEapPai == sequencialPai) {
            dado.expandido = false;
            dado.visivel   = true;
            dados.push(dado);
        }

    });

    return dados;
};

export default etapas;