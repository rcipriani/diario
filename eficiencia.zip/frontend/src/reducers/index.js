import {combineReducers} from 'redux';
import {routerReducer} from 'react-router-redux';
import {reducer as formReducer} from 'redux-form';
import app from './app';
import painel from './painel';
import etapas from './etapas';
import indicadoresProcessos from './indicadoresProcessos';
import resumoResultados from './resumoResultados';

export default combineReducers({
    app,
    painel,
    etapas,
    indicadoresProcessos,
    resumoResultados,
    form: formReducer,
    routing: routerReducer,
})

