import * as types from 'actions/indicadoresProcessos';

const initialState = [];

const indicadoresProcessos = (state = initialState, action) => {

    switch (action.type) {
        case types.BUSCA_INDICADORES_PROCESSO_SUCCESS:
            return action.payload;
    }

    return state;

};

export default indicadoresProcessos;