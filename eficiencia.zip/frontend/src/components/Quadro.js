import React, { Component } from 'react'
import css from './Quadro.css'

class Quadro extends Component {

    static propTypes = {
        titulo: React.PropTypes.string,
        initOpen: React.PropTypes.bool
    }

    static defaultProps = {
        titulo: null,
        initOpen: true
    }

    componentDidMount() {
        $('.collapsible').collapsible({
            accordion: false // A setting that changes the collapsible behavior to expandable instead of the default accordion style
        });
    }

    render() {

        const { children, titulo, initOpen } = this.props;

        return (
            <ul className="row card collapsible" data-collapsible="accordion">
                <li className={['', (initOpen ? 'active' : '')].join(' ')}>
                    {titulo &&
                        <div className={['collapsible-header blue-text', (initOpen ? 'active' : '')].join(' ')}>
                            {titulo}
                        </div>
                    }
                    <div className="collapsible-body" style={{ display: 'block' }}>
                        {children}
                    </div>
                </li>
            </ul>
        );

    }

};

export default Quadro;