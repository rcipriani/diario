import React from 'react'

export const Secao = (props) => {

    const {titulo, children} = props;

    return (
        <div className="" >

            <div className="row">
                <h2 className="col s12 header white-text" style={{textShadow: '0px 2px 2px #000'}}>{titulo}</h2>
            </div>

            {children}
        </div>
    )
};

export default Secao;