/**
 * Created by f9329476 on 24/01/2017.
 */

import React from 'react'
import Data from 'components/Data'

const TabelaEtapasIniciadas = (props) => {

    const {etapasIniciadas, onClickExpansor} = props;

    return (
        <table className="striped">
            <thead>
                <tr>
                    <td>
                        Processo / Ação / Etapa
                    </td>
                    <td>
                        Nome Responsável
                    </td>
                    <td>
                        Término Previsto
                    </td>
                </tr>
            </thead>
            <tbody>
                {etapasIniciadas.map((dado, index) => {
                    return dado.visivel && <tr key={dado.key}>
                        <td>
                            <div style={{ marginLeft: dado.nivel * 30 }}>
                                {dado.pai && <i className={['fa', css.link, (dado.expandido ? 'fa-minus' : 'fa-plus')].join(' ')} aria-hidden="true" onClick={e => onClickExpansor(dado)}>&nbsp;</i>}
                                {dado.tarefa.nome}
                            </div>
                        </td>
                        <td>
                            {dado.gestor.nome}
                        </td>
                        <td>
                            <Data data={dado.dataPrevistaFim}/>
                        </td>

                    </tr>
                })}
            </tbody>
        </table>
    );

};

export default TabelaEtapasIniciadas;