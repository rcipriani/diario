/**
 * Created by f9329476 on 24/01/2017.
 */

import React from 'react'
import Farol from './Farol'
import css from './TabelaProcessos.css'

const TabelaProjeto = (props) => {

    const {projeto} = props;

    return (
        <table className="bordered striped highlight">
            <thead className={css.subtitulo}>
                <tr>
                    <td >
                        Tema
                    </td>
                    <td >
                        % Previsto
                    </td>
                    <td >
                        % Realizado
                    </td>
                    <td >
                        Farol
                    </td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        {projeto.nome}
                    </td>
                    <td className="center-align">
                        {projeto.dataPrevistaFim ? 100 : 0}
                    </td>
                    <td className="center-align">
                        {projeto.percentualExecutado ? projeto.percentualExecutado.toFixed(0) : 0}
                    </td>
                    <td className="center-align">
                        <Farol cp={projeto.cp}></Farol>
                    </td>
                </tr>
            </tbody>
        </table>
    )
};

export default TabelaProjeto;