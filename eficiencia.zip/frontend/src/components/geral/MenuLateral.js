/**
 * Created by f9329476 on 02/02/2017.
 */
import React, {Component} from 'react'
import {SERVER_BASE_URL, STATIC_SERVER_URL} from 'config';
import css from './MenuLateral.css';
import RouterLink from 'bb-react-elements/RouterLink';
import {routeCodes} from 'routes';

class MenuLateral extends Component {

    constructor(props) {
        super(props);
    }

    componentDidMount() {
        $('.collapsible').collapsible();
    }

    menuProcessosItens = [
        {label: 'Painel', to: routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_PAINEL},
        {label: 'Etapas Iniciadas', to: routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_ETAPAS_INICIADAS},
        {label: 'Etapas Canceladas', to: routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_ETAPAS_CANCELADAS},
        {label: 'Etapas', to: routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_ETAPAS},
        {label: 'Resumo dos Resultados', to: routeCodes.COMPRAS_CONTRATACOES_PROCESSOS_RESUMO_RESULTADOS},
    ];

    menuDespesasItens = [
        {label: 'Painel', to: routeCodes.COMPRAS_CONTRATACOES_DESPESAS_PAINEL},
        {label: 'Etapas Iniciadas', to: routeCodes.COMPRAS_CONTRATACOES_DESPESAS_ETAPAS_INICIADAS},
        {label: 'Etapas Canceladas', to: routeCodes.COMPRAS_CONTRATACOES_DESPESAS_ETAPAS_CANCELADAS},
        {label: 'Resumo dos Resultados', to: routeCodes.COMPRAS_CONTRATACOES_DESPESAS_RESUMO_RESULTADOS},
    ];

    montaItensMenu = (itens) => {
        return itens.map((item, i) => (
            <li key={i}>
                <RouterLink to={item.to}>
                    {item.label}
                </RouterLink>
            </li>
        ));
    };

    render() {

        const {usuario, isFixed} = this.props;

        return (
            <ul id="slide-out" className={['side-nav', (isFixed ? 'fixed' : '')].join(' ')}>
                <li>
                    <div className="userView">
                        <img className="background background-cover"
                             src={`${STATIC_SERVER_URL}/imgs/commons/banner-usuario.png`}/>
                        <a href="#!user">
                            <img className="circle"
                                 src={`https://connections.bb.com.br/profiles/photo.do?uid=${usuario.chave}`}/>
                        </a>
                        <a href="#!name"><span className="white-text name">{usuario.nome}</span></a>
                        <a href="#!email"><span className="white-text email">{usuario.chave}</span></a>
                    </div>
                </li>
                <li><h5 style={{paddingLeft: '10px'}}>Gestão da Eficiência</h5></li>
                <li><a className="subheader">Compras e Contratações</a></li>
                <li>
                    <ul className="collapsible collapsible-accordion" data-collapsible="accordion">
                        <li>
                            <div className="collapsible-header ">Frente Processos</div>
                            <div className="collapsible-body">
                                <ul>
                                    {this.montaItensMenu(this.menuProcessosItens)}
                                </ul>
                            </div>
                        </li>
                        <li>
                            <div className="collapsible-header ">Frente Despesas</div>
                            <div className="collapsible-body">
                                <ul>
                                    {this.montaItensMenu(this.menuDespesasItens)}
                                </ul>
                            </div>
                        </li>
                    </ul>
                </li>
                <li>
                    <div className="divider"></div>
                </li>
                <li>
                    <RouterLink to={routeCodes.COMPRAS_CONTRATACOES_INDICADORES}>
                        Indicadores por Processo
                    </RouterLink>
                </li>
            </ul>
        );

    }


}

export default MenuLateral;