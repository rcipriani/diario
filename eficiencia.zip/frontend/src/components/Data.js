/**
 * Created by F9329476 on 24/01/2017.
 */

import React, {PureComponent} from 'react'
import moment from 'moment'
import css from './Farol.css'

class Data extends PureComponent {

    constructor(props) {
        super(props);
    }



    render() {

        let {formato, data} = this.props;

        if (!data) return null;

        formato = formato || 'DD/MM/YYYY';

        let resultado = moment(data).format(formato);

        return (
            <span>{resultado}</span>
        );

    }
}

export default Data;