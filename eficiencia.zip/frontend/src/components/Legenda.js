import React from 'react'
import css from './Legenda.css'

const Legenda = (props) => {

    const {qtdAtraso, qtdImpactada} = props;

    return (
        <table>
            <tbody>
            <tr>
                <td className={css.item}>
                    <span>Qtde de etapas em atraso</span>
                </td>
                <td>
                    <span>{qtdImpactada || 0}</span>
                </td>
            </tr>
            <tr>
                <td className={css.item}>
                    <span>Qtde de ações impactadas</span>
                </td>
                <td>
                    <span>{qtdAtraso || 0}</span>
                </td>
            </tr>
            </tbody>
        </table>
    )
};

export default Legenda;