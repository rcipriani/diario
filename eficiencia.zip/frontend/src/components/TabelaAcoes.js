import React, {Component} from 'react';
import css from './TabelaAcoes.css';
import Data from 'components/Data';

class TabelaAcoes extends Component {

    constructor(props) {
        super(props);
    }

    render() {

        const {dadosAnalitico, onClickExpansor} = this.props;

        return (
            <table className="bordered highlight">
                <thead className={css.subtitulo}>
                <tr>
                    <td>
                        Ação/Etapa em Atraso
                    </td>
                    <td>
                        Nome Responsável
                    </td>
                    <td>
                        Percentual Executado
                    </td>
                    <td>
                        Término Previsto
                    </td>
                </tr>
                </thead>
                <tbody>
                {
                    dadosAnalitico.map((dado, index) => {

                        let InicialContramedida = false;

                        return dado.visivel &&
                            <tr key={dado.key}
                                className={[(dado.pai ? css.link : ''), css['dado-nivel-' + dado.nivel]].join(' ')}
                                onClick={e => onClickExpansor(dado, index)}>
                                <td>
                                    {dado.nivel > 0 &&
                                    <i style={{float: 'left'}} className="fa fa-level-up fa-rotate-90"
                                       aria-hidden="true"></i>
                                    }
                                    <div style={{marginLeft: dado.nivel * 30, position: 'relative'}}>
                                        <div style={{marginRight: '120px'}}>{dado.nomeTarefa}</div>
                                        {dado.nivel > 0 &&
                                            <div style={{position: 'absolute', right: '0px', top: '0px'}}>
                                                <span className={['chip lighten-5', (InicialContramedida ? 'red' : 'blue')].join(' ')}>
                                                    {InicialContramedida ? 'Contramedida' : 'Inicial'}
                                                </span></div>}
                                    </div>
                                </td>
                                <td>
                                    {dado.nomeUsuario &&
                                    dado.nomeUsuario.split(' ').map(p => {
                                        return (['da', 'das', 'de', 'do', 'dos'].indexOf(p) > -1) ? p + ' ' : _.capitalize(p) + ' '
                                    })
                                    }
                                </td>
                                <td className="center-align">
                                    {dado.percentualExecucao.toFixed(0)}%
                                </td>
                                <td className="center-align">
                                    <Data data={dado.dataFimPrevisto}/>
                                </td>
                                <td className={css.link}>
                                    {dado.pai &&
                                    <i className={['fa', (dado.expandido ? ' fa-angle-down' : ' fa-angle-right')].join(' ')}
                                       aria-hidden="true">&nbsp;</i>
                                    }
                                </td>
                            </tr>
                    })
                }
                </tbody>
            </table>
        )
    }
}

export default TabelaAcoes;