import React from 'react'
import Farol from './Farol'
import Link from 'bb-react-elements/Link';
import css from './TabelaProcessos.css'

const TabelaProcessos = (props) => {

    const {dadosAnalitico, onClickEtapasAtraso} = props;

    return (
        <table className="bordered striped highlight">
            <thead className={css.subtitulo}>
                <tr>
                    <td rowSpan="2">
                        Processos
                    </td>
                    <td rowSpan="2">
                        Gestor
                    </td>
                    <td colSpan="3">
                        Execução das Ações
                    </td>
                    <td rowSpan="2">
                        Quantidade Etapas em Atraso
                    </td>
                </tr>
                <tr>
                    <td >
                        % Previsto
                    </td>
                    <td >
                        % Realizado
                    </td>
                    <td >
                        Farol
                    </td>
                </tr>
            </thead>
            <tbody>
                {
                    dadosAnalitico.map((dado, index) => {
                        return <tr key={index}>
                            <td>
                                {dado.tarefa.nome}
                            </td>
                            <td>
                                {dado.gestor.nome}
                            </td>
                            <td className="center-align">
                                {dado.percentualPrevisto ? dado.percentualPrevisto.toFixed(0) : 0}
                            </td>
                            <td className="center-align">
                                {dado.percentualRealizado ? dado.percentualRealizado.toFixed(0) : 0}
                            </td>
                            <td className="center-align">
                                <Farol cp={dado.cp}></Farol>
                            </td>
                            <td className="center-align">
                                <Link onClick={e => onClickEtapasAtraso(dado)}>{dado.qtdDescendentesEmAtraso - dado.qtdAcoesEmAtraso || 0}</Link>
                            </td>
                        </tr>
                    })
                }
            </tbody>
        </table>
    );

};

export default TabelaProcessos;