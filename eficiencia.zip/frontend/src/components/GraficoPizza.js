/**
 * Created by f9329476 on 23/01/2017.
 */

import React, { PureComponent } from 'react'

import _ from 'lodash';
import MomentHelper from 'helpers/moment-helper';
import Highcharts from 'highcharts';


class GraficoPizza extends PureComponent {

    static propTypes = {
        dadosSintetico: React.PropTypes.array.isRequired,
        modoApresentacao: React.PropTypes.bool
    };

    static defaultProps = {
        dadosSintetico: [],
        modoApresentacao: false
    };

    constructor(props) {
        super(props);
        this.chart = null;
        this.modules = [];

        this.id = "graficoPizza" + Math.random();

        this.state = {
            dadosSintetico: this.props.dadosSintetico
        };
    }

    getCss(){
        const css = {
            fontSize: '12px'
        };
        if(this.props.modoApresentacao){
            css.fontSize = '18px';
        }else{

        }
        return css;
    }

    componentDidMount() {

        if (this.modules) {
            this.modules.forEach(function (module) {
                module(Highcharts);
            });
        }

        let _self = this;
        const config = {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                options3d: {
                    enabled: true,
                    alpha: 45,
                    beta: 0
                },
                style: {
                    fontFamily: '"Roboto", sans-serif'
                }
            },
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Ações',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                pie: {
                    cursor: 'pointer',
                    showInLegend: true,
                    pointLabels: true
                    // dataLabels: {
                    //     enabled: true,
                    //     format: '{point.name}'
                    // }

                },
                series: {
                    states: {
                        select: {
                            color: '#003658'
                        }
                    },
                    cursor: 'pointer',
                    point: {
                        events: {
                            click: function () {
                                this.slice(null);
                                this.select(null, true);
                                _self.onChartBarClick(this.series.chart.getSelectedPoints());
                            }
                        }
                    },
                    dataLabels: {
                        enabled: true,
                        format: '{point.percentage:.1f} %',
                        style: {
                            color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black',
                        }
                    }
                }
            },
            credits: {
                enabled: false
            }
        };

        this.options = Highcharts.merge(config, {
            series: [{
                name: 'status',
                type: 'pie',
                colorByPoint: true,
                allowPointSelect: false,
                data: []
            }]

        });

        if (this.props.dadosSintetico)
            this.montaGrafico();

    }


    componentDidUpdate(prevProps, prevState) {
        if (this.props.dadosSintetico && prevProps.dadosSintetico != this.props.dadosSintetico) {
            this.montaGrafico();
        }
        if (this.props.modoApresentacao != null && prevProps.modoApresentacao != this.props.modoApresentacao) {
            this.toggleModoApresentacao();
        }
    }

    toggleModoApresentacao = () => {

        this.options.plotOptions.series.dataLabels.style.fontSize = this.getCss().fontSize;
        this.options.legend =  {
            itemStyle: {
                fontSize: this.getCss().fontSize,
                    font: this.getCss().fontSize,
            },
        };

        this.chart = new Highcharts[this.props.type || 'Chart'](
            this.id,
            this.options
        );

    };

    componentWillUnmount() {
        if (this.chart) {
            this.destroyChart();
        }
    }

    montaGrafico() {
        const {dadosSintetico, modoApresentacao} = this.props;

        let dados = [];

        dados = dadosSintetico.map(dado => ({
            name: dado.descricao,
            y: dado.qtd
        }
        ));

        this.chart = new Highcharts[this.props.type || 'Chart'](
            this.id,
            this.options
        );

        this.chart.series[0].setData(dados);
    }

    destroyChart() {
        this.chart.destroy();
    }

    render() {

        const {dadosSintetico, chipsFiltros} = this.props;

        return (
            <div id={this.id}></div>
        );
    }
}

export default GraficoPizza;