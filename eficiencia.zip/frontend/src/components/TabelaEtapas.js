import React from 'react';
import css from './TabelaEtapas.css';
import Data from 'components/Data';
import _ from 'lodash';

const TabelaEtapas = (props) => {

    const {etapas, onClickExpansor, showTerminoPrevisto} = props;

    return (
        <table>
            <thead>
            <tr>
                <th>
                    Processo / Ação / Etapa
                </th>
                <th>
                    Nome Responsável
                </th>
                {showTerminoPrevisto &&
                <th>
                    Término Previsto
                </th>
                }
                <td style={{width: '30px'}}></td>
            </tr>
            </thead>
            <tbody>
            {etapas.map((dado, index) => {
                return dado.visivel &&
                    <tr className={[(dado.expandido ? css.borderBotton : ''), (dado.pai ? css.link : ''), css['dado-nivel-'+dado.nivel]].join(' ')}
                        onClick={e => onClickExpansor(dado.sequencialTarefaEap, index)} key={dado.key}>
                        <td>
                            <div style={{marginLeft: dado.nivel * 20}}>
                                {dado.nivel > 1 &&
                                    <i style={{float: 'left', marginRight: '10px'}} className="fa fa-level-up fa-rotate-90" aria-hidden="true"></i>
                                }
                                <span style={{height: '100%'}}>
                                    {dado.nomeTarefa}
                                </span>
                            </div>
                        </td>
                        <td>
                            {dado.nomeUsuario &&
                                dado.nomeUsuario.split(' ').map(p => {
                                    return (['da', 'das', 'de', 'do', 'dos'].indexOf(p) > -1) ? p + ' ' : _.capitalize(p) + ' '
                                })
                            }
                        </td>
                        {showTerminoPrevisto &&
                        <td>
                            <Data data={dado.dataFimPrevisto}/>
                        </td>
                        }
                        <td>
                            {dado.pai &&
                            <i className={['fa', (dado.expandido ? ' fa-angle-down' : ' fa-angle-right')].join(' ')}
                               aria-hidden="true" onClick={e => onClickExpansor(dado)}>&nbsp;</i>
                            }
                        </td>
                    </tr>
            })}
            </tbody>
        </table>
    );

};

TabelaEtapas.propTypes = {
    etapas: React.PropTypes.array.isRequired,
    onClickExpansor: React.PropTypes.func.isRequired,
    showTerminoPrevisto: React.PropTypes.bool
};

TabelaEtapas.defaultProps = {
    etapas: [],
    onClickExpansor: {},
    showTerminoPrevisto: true
};

export default TabelaEtapas;