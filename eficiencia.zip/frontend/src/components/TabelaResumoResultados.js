import React, {Component} from 'react';

import Data from 'components/Data';
import Aviso from 'components/Aviso';

import css from './TabelaResumoResultados.css';
import Mes from 'lib/mes';
import Modal from 'bb-react-elements/Modal';
import Link from 'bb-react-elements/Link';
import Grafico from 'bb-react-elements/graficos/Grafico';
import Farol from 'components/Farol';


class TabelaResumoResultados extends Component {

    state = {
        open: false,
        anchorEl: null,
        detalhe: null,
        detalhesIndicador: null,
        isModalDetalhaPendenciaOpen: false,
        isModalDetalheIndicadorOpen: false
    };

    colunas = ['meta', 'real', 'desvio'];

    colunaApuracoes = (indicador, processoId) => {

        return this.props.periodos.map((periodo, index) => {

            const valorPeriodo = indicador.apuracoes[index];

            const valorMeta = valorPeriodo.meta;
            const valorReal = valorPeriodo.real;
            const valorDesvio = valorPeriodo.desvio;
            const cp = valorDesvio > 0 ? 100 : 0;

            if (!valorMeta && !valorReal) return (

                this.colunas.map((coluna, indexColuna) => {

                    const posicao = index;
                    const isPar = posicao % 2 == 0;

                    return (
                        <td key={indexColuna + index + 1} className={css.dados + ' ' + (isPar ? css.colunaEven : '')}>
                            <span>-</span>
                        </td>
                    )

                })
            );

            if (!valorMeta) return (
                <td colSpan="3" className={css.texto}>
                    <Link onClick={
                        e => this.props.onClickDetalhePendencia(processoId, indicador.id, periodo.ano, periodo.mes)
                    }
                          className={['waves-effect waves-light btn grey darken-2', css.botaoPendencia].join(' ')}>
                        Meta Pendente
                    </Link>
                </td>
            );

            if (!valorReal) return (
                <td colSpan="3" className={css.texto}>
                    <Link onClick={
                        e => this.props.onClickDetalhePendencia(processoId, indicador.id, periodo.ano, periodo.mes)
                    }
                          className={['waves-effect waves-light btn red darken-4', css.botaoPendencia].join(' ')}>
                        Resultado Pendente
                    </Link>
                </td>
            );

            return (

                this.colunas.map((coluna, indexColuna) => {

                    const valor = valorPeriodo[coluna];
                    const isDesvio = indexColuna == this.colunas.length - 1;
                    const posicao = index;
                    const isPar = posicao % 2 == 0;

                    let classeCor = '';

                    switch (indexColuna) {
                        case 0:
                            classeCor = 'grey';
                            break;
                        case 1:
                            classeCor = 'blue lighten-2';
                            break;
                        case 2:
                            classeCor = valor > 0 ? 'green lighten-2' : 'red lighten-2';
                            break;
                    }

                    let valorPositivo = ((indicador.indicadorDesempenho && valorDesvio > 0)
                                            || (!indicador.indicadorDesempenho && valorDesvio < 0));

                    return (
                        <td key={indexColuna + index + 1} className={css.dados + ' ' + (isPar ? css.colunaEven : '')}>

                            <span className={isDesvio ? (valorPositivo ? css.positivo : css.negativo) : null}>
                                {valor < 1 && valor > 0 || valor > -1 && valor < 0 ? valor.toFixed(2).replace('.', ',') : valor}
                            </span>

                            {isDesvio &&
                            <span style={{float: 'right'}}>
                                    <Farol cp={valorPositivo ? 100 : 0} className={css.farol}/>
                                </span>
                            }


                            {/*<div style={{height: Math.abs((valor / 2))}} className={classeCor + " " + css.barra}></div>*/}

                        </td >
                    )

                })
            )

        });

    };

    linhaProcesso = (props) => {

        const {processo} = props;

        return processo.indicadores.map((indicador, index) => (

            <tr key={index} className={css.indicador}>

                {
                    index == 0 &&
                    <td rowSpan={processo.indicadores.length}>
                        {processo.nome}
                    </td>
                }

                <td>
                    {indicador.nome}
                </td>
                <td>
                    <Link onClick={e => this.props.onClickDetalheIndicador(indicador)}>
                        <i className={"fa fa-info-circle "}
                           title="Mais detalhes do indicador."></i>
                    </Link>
                    <br/>
                    <Link onClick={e => this.detalharIndicador(processo, indicador)}>
                        <i className="fa fa-bar-chart" aria-hidden="true"></i>
                    </Link>
                </td>

                {this.colunaApuracoes(indicador, processo.id)}

            </tr>

        ));

    };

    detalharIndicador(processo, indicador) {

        const series = [{
            name: 'Realizado',
            type: 'column',
            data: [],
            tooltip: {
                valueSuffix: ' %'
            },
        }, {
            name: 'Meta',
            type: 'spline',
            data: [],
            tooltip: {
                valueSuffix: '%'
            }
        }];

        indicador.apuracoes.forEach(apuracao => {
            series[0].data.push(apuracao.real);
            series[1].data.push(apuracao.meta);
        });

        console.log(processo, indicador);
        this.setState({
            detalhesIndicador: {
                titulo: `${processo.nome}: ${indicador.nome}`,
                series: series,
                categories: indicador.apuracoes.map(
                    apuracao => `${Mes.getByNumero(apuracao.mes).nome.substring(0, 3).toUpperCase()}\\${apuracao.ano}`
                )
            }
        });
    }

    componentDidUpdate(prevProps, prevState) {

        //o detalhe do indicador foi alterado
        if (this.props.detalheIndicador
            && this.props.detalheIndicador != prevProps.detalheIndicador
            && !this.state.open) {

            this.setState({
                open: true,
                detalhe: this.props.detalheIndicador
            });

        }

        if (this.props.detalhePendencia
            && this.props.detalhePendencia != prevProps.detalhePendencia
            && !this.state.open) {

            this.setState({
                isModalDetalhaPendenciaOpen: true,
                detalhePendencia: this.props.detalhePendencia
            });

        }

    }

    handleCloseModal() {
        this.setState({
            open: false
        })
    }

    handleCloseModalDetalhaPendencia() {
        this.setState({
            isModalDetalhaPendenciaOpen: false
        })
    }

    render() {

        const {periodos, processos, detalheIndicador, onClickDetalheIndicador, modoApresentacao} = this.props;

        const {detalhe, detalhePendencia, detalhesIndicador} = this.state;

        const montaPendencias = (detalhePendencia) => {

            if (!detalhePendencia || detalhePendencia.length <= 0)
                return <Aviso>Não há pendências registradas</Aviso>;

            return detalhePendencia.map(dado => {
                return dado &&
                    <div key={dado.key} className="row">
                        <div className="col s4">
                            <strong><Data data={dado.prazoRegularizacao}/></strong>
                        </div>
                        <div className="col s4">
                            <strong>{dado.matriculaResponsavel}</strong>
                        </div>
                        <div className="col s4">
                            <strong>{dado.tipoOcorrencia == 1 ? 'Meta pendente' : 'Resultado pendente'}</strong>
                        </div>
                        <div className="col s12">
                            {dado.textoOcorrencia}
                        </div>
                    </div>
            })
        };

        return (

            <div>
                <Modal title={detalhesIndicador ? detalhesIndicador.titulo : ''}
                       open={detalhesIndicador != null}
                       onRequestClose={() => this.setState({detalhesIndicador: null})}>
                    {detalhesIndicador &&
                        <Grafico series={detalhesIndicador.series} categories={detalhesIndicador.categories} modoApresentacao={modoApresentacao}/>
                    }

                </Modal>

                <Modal title="Pendências"
                       open={this.state.isModalDetalhaPendenciaOpen}
                       onRequestClose={this.handleCloseModalDetalhaPendencia.bind(this)}>
                    {detalhePendencia && montaPendencias(detalhePendencia)}

                </Modal>

                <Modal title={detalhe ? detalhe.nomeIndicador : ''} open={this.state.open}
                       onRequestClose={this.handleCloseModal.bind(this)}>
                    {detalhe &&

                    <table className="striped">
                        <tbody>

                        <tr>
                            <td>
                                <strong>Descrição</strong>
                            </td>

                            <td>
                                {detalhe.descricaoIndicador}
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>Fórmula</strong>
                            </td>

                            <td>
                                {detalhe.formaCalculoIndicador}
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>Periodicidade</strong>
                            </td>

                            <td>
                                {detalhe.periodicidade.descricaoPeriodicidade}
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>Unidade de medida</strong>
                            </td>

                            <td>
                                {detalhe.unidadeMedidaIndicador}
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>Indicador de desempenho</strong>
                            </td>

                            <td>{detalhe.indicadorDesempenho ?
                                <i className="fa fa-arrow-up" aria-hidden="true"></i>
                                : <i className="fa fa-arrow-down" aria-hidden="true"></i>}
                            </td>
                        </tr>

                        </tbody>

                    </table>

                    }

                </Modal>

                <table className={css.tabelaGrafico}>

                    <thead className={css.cabecalho}>
                    <tr>
                        <td rowSpan="2">
                            PROCESSO
                        </td>
                        <td rowSpan="2" colSpan="2">
                            INDICADORES
                        </td>
                        {periodos.map((periodo, index) => {

                            const mes = Mes.getByNumero(periodo.mes);
                            const mesNome = mes.nome.substring(0, 3).toUpperCase();

                            return (
                                <td colSpan="3" key={index}>
                                    {mesNome + '/' + periodo.ano}
                                </td >
                            )
                        })}
                    </tr>
                    <tr>
                        {periodos.map((periodo, index) => (
                            this.colunas.map((coluna, indexColuna) => (
                                <td key={index + indexColuna + 1} className={css.cabecalhoDados}>
                                    {coluna.toUpperCase()}
                                </td>
                            ))
                        ))}
                    </tr>
                    </thead>

                    <tbody>

                    {processos.map((processo, indexProcesso) => (

                        this.linhaProcesso({processo})

                    ))}

                    </tbody>


                </table>

            </div>
        )
    }
}

export default TabelaResumoResultados;