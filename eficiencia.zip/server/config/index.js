module.exports ={

    port: 3008,
    
    path: 'eficiencia',

    maxAge : 36000

}