const path = require('path');
const modulePath = require('app-module-path');

modulePath.addPath(path.join(__dirname, '/../../api/'));
modulePath.addPath(path.join(__dirname, '/../../api/node_modules/'));
modulePath.addPath(path.join(__dirname, '/../../'));

const config = require('./config');
const express = require('express');
const ambiente = process.env.AMBIENTE || 'desenvolvimento';
const helmet = require('helmet');
const compression = require('compression');
const autenticacao = require('common/autenticacao');
const cookieParser = require('cookie-parser');
const sessao = require('common/sessao');
const acesso = require('common/acesso');
const cluster = require('cluster');
const app = express();
const ROOT_PATH = path.join(__dirname, '/../frontend/public');

app.use(helmet.hidePoweredBy({
    setTo: 'USI 0.1.0'
}));

app.use((req, res, next) => {

    const file = /(.js|.css)$/.test(req.path) ? path.basename(req.path) : 'index.html'

    const filePath = path.join(ROOT_PATH, file);

    res.sendFile(filePath);

});


/*app.use(cookieParser());
app.use(sessao().filtro);
app.use(autenticacao);
app.use(acesso);
*/

//compressão do response, performance
app.use(compression());

app.use(express.static(ROOT_PATH, {
    maxAge: config.maxAge
}));

//Definição do cluster
if (cluster.isMaster) {

    // Count the machine's CPUs
    const workers = require('os').cpus().length;

    // Create a worker for each CPU
    for (let i = 0; i < workers; i += 1) {
        cluster.fork();
    }

    // Code to run if we're in a worker process
} else {

    // Add a basic route – index page

    // Bind to a port
    const server = app.listen(config.port, () => {

        let host = server.address().address;
        let port = server.address().port;

        console.log('Servidor escutando na porta %s', port);
        console.log('Ambiente de %s', ambiente);

    });
}

//usado para testes
module.exports = app;